<?php

if(isset($_POST['Submit'])){

  $username =$_POST['username'];
  $password =$_POST['password'];
  $conn = mysqli_connect("localhost","root","","Project");



  $sql="select * from admin where username='".$username."'";


  $result=mysqli_query($conn,$sql);
  $row=mysqli_num_rows($result);
  if($row > 0){
    $record=mysqli_fetch_assoc($result);

    $db_username=$record['username'];
    $db_password=$record['password'];

    if($username === $db_username && $password === $db_password){

      session_start();

      $_SESSION['name']=$record['name'];

      header ('Location: dash_bord.php');

    }else {
      header('Location: login_form.php?msg=Invalid username or password');

    }

    }else {
      header('Location: index.php?msg=pls Rgister with us Thank you');
    }

  }else{
    header('Location:index.php?msg=pls resiter');
  }








 ?>

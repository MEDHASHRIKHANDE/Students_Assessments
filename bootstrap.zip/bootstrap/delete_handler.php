<?php

if(isset($_POST['delete'])){

  $conn = mysqli_connect("localhost","root","","Project");
  $username=$_POST['username'];


  $sql = "delete from admin where username ='".$username."'";
  $result=mysqli_query($conn,$sql);

  if($result){

    echo "delete complited";
  }

  else{
    echo "delete not complited";
  }
}
else{
  echo "sorry some thing not done";
}

 ?>

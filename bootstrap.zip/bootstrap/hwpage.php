<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <link rel="stylesheet" href="css/bootstrap.min.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title></title>
  </head>
  <body>

    <div class="conainer-fluid bg-dark"style="padding:1em;">
        <div class="row">

          <div class="col-lg-2">
            <b style="color:white">Online Notice board</b>
          </div>

          <div class="col-lg-1">
            <a href="#"style="color:white;"><i class="fa fa-address-book" aria-hidden="true"style="color:white;"></i>  About</a>

          </div>

          <div class="col-lg-1">
    <a href="#"style="color:white;"><i class="fa fa-mobile" aria-hidden="true"style="color:white;"></i>  Contact</a>
   </div>


   <div class="col-lg-6">

   </div>

          <div class="col-lg-1">
            <a href="signup.php"style="color:white;"><i class="fa fa-user" aria-hidden="true"style="color:white;">  Signup</i></a>

          </div>
          <div class="col-lg-1">
            <a href="login.php"><i class="fa fa-sign-in" aria-hidden="true"style="color:white;border:black;">  Login</i></a>
          </div>

        </div>
    </div>



<div class="container-fluid">
  <div class="row">
    <div class="col-lg-12">


    <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
      <div class="carousel-inner">
        <div class="carousel-item active">
          <img src="image/Desert.jpg" class="d-block w-100 h-50" alt="..." >
        </div>

        <div class="carousel-item">
          <img src="image/Jellyfish.jpg" class="d-block w-100 h-50 " alt="..." >
        </div>

        <div class="carousel-item">
          <img src="image/Penguins.jpg"class="d-block w-100 h-50" >
          </div>

      </div>
      <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
      </a>
      <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
      </a>
    </div>
  </div>
    </div>
    </div>

<div class="container-fluid"style="padding:2em;">

  <div class="row">

    <div class="col-lg-5">
      <h1 style="color:yellowgreen;">Quick Contact</h1>
      ENTER YOUR EMAIL &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="email" name="email"style="border-radius:5px;" ><br><br>
      ENTER YOUR MOBAIL&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="tel" name="contact"style="border-radius:5px;" ><br><br>
      ENTER YOUR MESSAGE&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="text" name="message"style="border-radius:5px;"><br><br>
       <button type="submit" class="btn btn bg-success " style="border:solid green 1px; color:white;"> Send Query</button>
    </div>


    <div class="col-lg-3">
      <h3 style="color:yellowgreen;">Contact us</h3><br>
      Name:  Neeraj Kumar<br>
      Mobail:7065770056<br>
      Email:neerajkumar21997@gmail.com<br>
      Website:<b style="color:blue;">phptprint.com </b>
    </div>

    <div class="col-lg-4">
      <div class="card">
  <div class="card-header">
    Latest news
  </div>
  <div class="card-body">

    <p class="card-text">this is best website hou can search anytimgs here the best thum.</p>

  </div>
</div>
    </div>

  </div>
</div>

    <script type="text/javascript" src="js/jquery-3.4.1.min.js">

    </script>
<script type="text/javascript" src="js/bootstrap.min.js">

    </script>

  </body>
</html>

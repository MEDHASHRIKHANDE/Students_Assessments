<?php
$conn = mysqli_connect("localhost","root","","Project");
if($conn){
$name =$_POST['name'];
$username =$_POST['username'];
$email =$_POST['email'];
$password =$_POST['password'];
$contact =$_POST['contact'];
$male =$_POST['male'];
$female =$_POST['female'];
$reading =$_POST['reading'];
$singing =$_POST['singing'];
$cricket =$_POST['cricket'];
$date =$_POST['date'];

$sql="insert into admin values(null,'".$name."','".$username."','".$email."','".$password."','".$contact."','".$male."','".$female."','".$reading."','".$singing."','".$cricket."','".$date."')";
$result=mysqli_query($conn,$sql);
if($result){
  echo "query is created";
}
else {
  echo "query is not created";
}
}
else{
  echo " sorry data base is not connected";
}
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <link rel="stylesheet" href="css/bootstrap.min.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title></title>
  </head>
  <body>

    <div class="conainer-fluid bg-dark"style="padding:1em;">
        <div class="row">

          <div class="col-lg-2">
            <b style="color:white">Online Notice board</b>
          </div>

   <div class="col-lg-9">
   </div>

          <div class="col-lg-1">
            <a href="#"><i class="fa fa-sign-in" aria-hidden="true"style="color:white;border:black;">  Login</i></a>
          </div>

        </div>
    </div>

<div class="container-fluid"style="padding:1em;">
<div class="row">
  <div class="col-lg-4">

    <button type="submit" class="btn btn bg-primary " style="border:solid blue 1px; color:white;width:17vw;margin-left:-1vw;"><b style="margin-left:-8vw;">Dashboard</b></button><br><br>

    <i class="fa fa-user" aria-hidden="true"style="font-size:30vh;color:yellowgreen;"></i><br><br>


      <i class="fa fa-user" aria-hidden="true"style="font-size:5vh;color:blue;"></i>
<a href="update_password.php">Update password</a><br><br>
<i class="fa fa-user" aria-hidden="true"style="font-size:5vh;color:blue;"></i>
<a href="update_profile.php">Update Profile</a><br><br>
<i class="fa fa-envelope" aria-hidden="true"style="font-size:4vh;color:blue;"></i>
<a href="notice.php">Notifaction</a><br><br>

</div>

<div class="col-lg-8">
<h1>Update Profile</h1>

  ENTER YOUR OLD &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="password" name="password"><br><br>
  ENTER YOUR NEW PASSWORD &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="password" name="password"><br><br>
  ENTER YOUR CONFIRM PASSWORD &nbsp&nbsp&nbsp&nbsp<input type="password" name="password"><br><br>

    <button type="submit" class="btn btn bg-success " style="border:solid yellowgreen 1px; color:white;margin-left:-1vw;"><b>Profile</b></button>&nbsp&nbsp&nbsp
    <button type="submit" class="btn btn bg-success " style="border:solid yellowgreen 1px; color:white;margin-left:-1vw;"><b>Reset</b></button>
</div>

</div>
</div>



    <script type="text/javascript" src="js/jquery-3.4.1.min.js">

    </script>
<script type="text/javascript" src="js/bootstrap.min.js">

    </script>

  </body>
</html>

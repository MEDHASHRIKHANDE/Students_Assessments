<?php

session_start();
if(isset($_SESSION['name'])){

  $db_name=$_SESSION['name'];

  echo "<h2 style='color:yellowgreen;'>welcome Mr/Mrs.".$db_name."</h1>";



}else{
  header('Location:login.php?msg=Invalid username or password');
}




 ?>

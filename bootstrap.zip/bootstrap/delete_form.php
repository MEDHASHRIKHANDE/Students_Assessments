<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <form class="" action="delete_handler.php" method="post">
      <h1 style="color:yellowgreen;">Delete form</h1>
      <input type="text" name="username" placeholder="username"style="border-radius:5px;"><br><br>
      <input type="submit" name="delete">

    </form>
  </body>
</html>

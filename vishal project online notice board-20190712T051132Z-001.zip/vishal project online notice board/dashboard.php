<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="css/bootstrap.css"/>
		<script src="js/jquery_library.js"></script>
<script src="js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  </head>
  <body>



    <div class="container-fluid">

      <nav class="navbar navbar-default navbar-fixed-top" style="background:#000">
        <div class="container">

        <ul class="nav navbar-nav navbar-left">
          <li><a href="index.php" style="color:white"><strong>Hello admin</strong></a></li>


        </ul>


      <ul class="nav navbar-nav navbar-right">
            <li><a href="logout.php" style="color:white"><span class="glyphicon glyphicon-user"></span> Logout</a></li>

          </ul>
        </div>
</nav>
</div><br><br><br>

<div class="container-fluid">

<div class="row">

  <div class="col-lg-3 lg-text-center">
      <h3 class="bg-info">Dashboard</h3>
    <img src="images/person.jpg">

    <a href="change_password.php" class="fa fa-key"> change password</a><br><br>
    <a href="manage_user.php"  class="fa fa-user">Manage User</a><br><br>
    <a href="addnotice.php" class="fa fa-bell"> Manage Notification</a><br><br>


  </div><br>
  <div class="col-lg-9">
    <div class="row">
<div class="col-lg-4">
  <div style="width:200px;height:200px;background-color:grey;border-radius:100px;">
  </div>
  <div style="margin-left:50px">
  <h2>Label</h2><br>
  <p>Something Else</p>
</div>
</div>

<div class="col-lg-4">
  <div style="width:200px;height:200px;background-color:grey;border-radius:100px;">
  </div>
  <div style="margin-left:50px">
  <h2>Label</h2><br>
  <p>Something Else</p>
</div>

</div>

<div class="col-lg-4">
  <div style="width:200px;height:200px;background-color:grey;border-radius:100px;">
  </div>
  <div style="margin-left:50px">
  <h2>Label</h2><br>
  <p>Something Else</p>
</div>
</div>

</div>

  </div>

</div>

</div>



  </body>
</html>

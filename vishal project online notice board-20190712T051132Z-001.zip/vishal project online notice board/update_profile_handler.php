<?php



  include 'dhp.php';
  if($conn){
  $name=$_POST['name'];
  $hobbie=$_POST['hob'];
  $password=$_POST['password'];
$sql="update user set password='$password', hobbie='$hobbie' where name='$name'";
$result=mysqli_query($conn,$sql);
if($result){
header ('location:index.php');

}

else{

echo"not updated";
}
}
else{

echo"error";
}












 ?>


    <!-- Header Start-->
    <?php include 'inc/header_inc.php'; ?>
    <!-- Header Ends -->
    <!-- Nav Bar Start-->
    <?php include 'inc/navbar_inc.php'; ?>
    <!-- Nav Bar Ends -->
    <!-- Silder Start -->
    <?php include 'inc/slider_inc.php'; ?>
    <!-- Silder Ends -->

    <div class="container-fulid">
      <div class="row p-0 m-0">
        <div class="col-lg-8 p-3">
        <p class="h2 text-center font-weight-bold text-primary">Welcome to Vision Technology</p>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation.</p>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
        </div>

        <div class="col-lg-4">

          <h2 class="text-center bg-dark p-2 my-3 text-light">Lates News</h2>
          <?php
          $sql ="select * from news";
          include 'dbh.php';
          $result=mysqli_query($conn,$sql);
          while ($row=mysqli_fetch_assoc($result)) {
            echo '

            <div class="container-fulid table-primary p-2 my-2">
            <p>'.$row["news"].'</p>
            <p class="font-weight-bold text-right">-- '.$row["author"].'</p>
            </div>

            ';
          }

           ?>


        </div>
      </div>
    </div>


    <!-- Footer Start -->
    <?php include 'inc/footer_inc.php'; ?>
    <!-- Footer Ends -->

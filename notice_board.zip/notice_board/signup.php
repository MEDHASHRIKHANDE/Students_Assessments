
    <!-- Header Start-->
    <?php include 'inc/header_inc.php'; ?>
    <!-- Header Ends -->
    <!-- Nav Bar Start-->
    <?php include 'inc/navbar_inc.php'; ?>
    <!-- Nav Bar Ends -->
    <!-- Silder Start -->
    <?php include 'inc/slider_inc.php'; ?>
    <!-- Silder Ends -->

    <div class="container-fulid  py-5" style="background-image:url(img/background/signup.jpg); background-size:cover;">
      <div class="container">
        <div class="row my-2">
          <div class="lg-5 p-3" style="border-radius:18px; border:5px solid #fff; background-color:rgba(0,0,0,0.5);">
            <h2 class="text-center text-light font-weight-bold my-2">Sign up</h2>

            <form class="" action="signup_handler.php" method="post" enctype="multipart/form-data">

              <div class="form-group">
                <input type="text" name="name" placeholder="Name" class="form-control p-1">
              </div>
              <div class="form-group">
                <input type="text" name="email" placeholder="Email Id" class="form-control p-1">
              </div>
              <div class="form-group">
                <input type="password" name="password" placeholder="Password" class="form-control p-1">
              </div>
              <div class="form-group">
                <input type="text" name="mobile" placeholder="Mobile" class="form-control p-1">
              </div>
              <div class="form-group">
                <label for="" class="text-light font-weight-bold h5">Gender :</label>
                <label class="text-light font-weight-bold m-1" for="male">Male</label> <input type="radio" id="male" name="gender" value="Male">
                 <label class="text-light font-weight-bold m-1" for="Female">Female</label> <input type="radio" id="Female" name="gender" value="Female">
              </div>
              <div class="form-group">
                <input type="file" name="img" class="form-control">
              </div>
              <div class="form-group">
                <input type="date" name="dob" class="form-control">
              </div>
              <div class="form-group">
                <input type="submit" name="submit" value="Signup" class=" btn-primary btn-block btn-lg">
              </div>
            </form>
          </div>

          <div class="col-lg-7 bg-light p-5"style="border-radius:18px; border:5px solid #fff;background-image:url(img/background/signup_side.jpeg); background-size:cover;">
            <p class="h1 text-light text-center">Welcome To Vision Technology</p>
            <p class="font-weight-bold text-light">lorem Lorem</p>
            <p class="text-light">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
            <p class="font-weight-bold text-light">lorem Lorem</p>
            <p class="text-light">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
          </div>

        </div>
      </div>
    </div>

    <!-- Footer Start -->
    <?php include 'inc/footer_inc.php'; ?>
    <!-- Footer Ends -->


    <!-- Header Start-->
    <?php include 'inc/header_inc.php';session_start() ?>
    <!-- Header Ends -->
    <!-- Nav Bar Start-->
    <?php include 'inc/navbar_inc.php'; ?>
    <!-- Nav Bar Ends -->


    <?php
    include '../dbh.php';
    $id=$_GET['id'];
    $sql = "SELECT * FROM notice where id=$id";
    $result= mysqli_query($conn,$sql);
    $row = mysqli_fetch_assoc($result);
    $name = $row['name'];
    $subject = $row['subject'];
    $decs = $row['decs'];

     ?>


    <div class="container-fulid  py-5" style="background-image:url(../img/background/signup.jpg); background-size:cover;">
      <div class="container">
          <div class=" p-3" style="border-radius:18px; border:5px solid #fff; background-color:rgba(0,0,0,0.6);">
            <h2 class="text-center text-light font-weight-bold my-2">Update Notice</h2>

            <div class="card p-5">
              <form class="" action="update_notice_handler.php" method="post">
                <div class="form-group">
                <label class="font-weight-bold" for="">Username</label>
                  <input type="text" name="name" value="<?php echo $_SESSION['name']; ?>" class="form-control form-control-lg" readonly>
                </div>
                <div class="form-group">
                <label class="font-weight-bold" for="">Subject</label>
                  <input type="text" name="subject" value="<?php echo $subject; ?>" class="form-control form-control-lg" required>
                  <input type="text" name="id" value="<?php echo $id; ?>" class="form-control form-control-lg" hidden>
                </div>
                <div class="form-group">
                <label class="font-weight-bold" for="">Description</label>
                  <input type="text"name="decs"  placeholder="Description" value="<?php echo $decs; ?>" class="form-control form-control-lg" required>
                </div>
                <div class="form-group">
                  <input type="submit" name="updatenotice" value="Add Notice" class="btn-lg btn-primary font-weight-bold btn-block" value="">
                </div>
              </form>
            </div>
          </div>

      </div>
    </div>

    <!-- Footer Start -->
    <?php include 'inc/footer_inc.php'; ?>
    <!-- Footer Ends -->


    <!-- Header Start-->
    <?php include 'inc/header_inc.php';session_start() ?>
    <!-- Header Ends -->
    <!-- Nav Bar Start-->
    <?php include 'inc/navbar_inc.php'; ?>
    <!-- Nav Bar Ends -->

    <div class="container-fulid  py-5" style="background-image:url(../img/background/signup.jpg); background-size:cover;">
      <div class="container">
          <div class=" p-3" style="border-radius:18px; border:5px solid #fff; background-color:rgba(0,0,0,0.6);">
            <h2 class="text-center text-light font-weight-bold my-2">Add Notice</h2>
            <?php
            if (isset($_GET['msg'])) {
             echo "<h2 class='text-center text-capitalize font-weight-bold'>";
             echo $_GET['msg'];
             echo "</h2>";
            }

             ?>
            <div class="card p-5">
              <form class="" action="addnotification_handler.php" method="post">
                <div class="form-group">
                <label class="font-weight-bold" for="">Username</label>
                  <input type="text" name="name" value="<?php echo $_SESSION['name']; ?>" class="form-control form-control-lg" readonly>
                </div>
                <div class="form-group">
                <label class="font-weight-bold" for="">Subject</label>
                  <input type="text" name="subject" class="form-control form-control-lg" required>
                </div>
                <div class="form-group">
                <label class="font-weight-bold" for="">Description</label>
                  <textarea name="decs"  placeholder="Description" class="form-control form-control-lg" required>
                  </textarea>
                </div>
                <div class="form-group">
                  <input type="submit" name="addnotice" value="Add Notice" class="btn-lg btn-primary font-weight-bold btn-block" value="">
                </div>
              </form>
            </div>
          </div>

      </div>
    </div>

    <!-- Footer Start -->
    <?php include 'inc/footer_inc.php'; ?>
    <!-- Footer Ends -->

<?php
session_start();
if (!isset($_SESSION['name'])) {
  header("Location: ../index.php");
} else {
  echo'';
?>

    <!-- Header Start-->
    <?php include 'inc/header_inc.php'; ?>
    <!-- Header Ends -->
    <!-- Nav Bar Start-->
    <?php include 'inc/navbar_inc.php'; ?>
    <!-- Nav Bar Ends -->



    <div class="container-fulid">
      <div class="row p-0 m-0">
        <div class="col-lg-3 col-md-3 col-sm-3 p-0">
          <p class="h3 font-weight-bold text-light bg-primary text-center p-2 my-2">Dashboard</p>
          <div class="w-50 mx-auto">
            <img src="../img/profile/<?php echo $_SESSION['profile']; ?>" class="img img-thumbnail w-100" alt="">
          </div>
          <div class="p-3">
          <p class="font-weight-bold h4 text-center"> Name of the User</p>
          <a href="updatepassword.php" class="link btn btn-primary btn-block"><span><i class="fa fa-pencil" aria-hidden="true"></i> </span> <b>Update Password</b> </a>
          <a href="veiwuser.php" class="link btn btn-primary btn-block"><span><i class="fas fa-user" aria-hidden="true"></i> </span> <b>Manage User</b> </a>
          <a href="addnotification.php" class="link btn btn-primary btn-block"><span><i class="fas fa-user" aria-hidden="true"></i> </span> <b>Manage Notification</b> </a>
          <a href="feedback.php" class="link btn btn-primary btn-block"><span><i class="fa fa-thumbs-up" aria-hidden="true"></i> </span> <b>Feedback</b> </a>

        </div>

        </div>
        <div class="col-lg-9 col-md-9 col-sm-9 p-3">
          <?php
          if (isset($_GET['msg'])) {
           echo "<h2 class='text-center text-capitalize font-weight-bold'>";
           echo $_GET['msg'];
           echo "</h2>";
          }

           ?>

          <?php
          if (!isset($_SESSION['feedback'])) {
            ?>
            <h2 class="font-weight-bold text-center"> Student Feedback Form </h2>
            <p class="h4 my-2"> Please give your answer about the folling Question by checking the options </p>
            <button type="button" class="btn btn-success" name="button">Strongly Agree</button>
            <button type="button" class="btn btn-primary" name="button">Agree</button>
            <button type="button" class="btn btn-info" name="button">Nutral</button>
            <button type="button" class="btn btn-warning" name="button">Desagree</button>
            <button type="button" class="btn btn-danger" name="button">Strongly Desagree</button>
            <br>
            <p class="mt-4">Select Faculity :</p>
            <form class="" action="feedback_handler.php" method="post">
              <div class="form-group my-2">
                <select class="form-control" name="facility_name">
                  <option value="">Pls Select The Faculity</option>
                </select>
              </div>
              <h3 class="my-4 font-weight-bold">1. Course Material</h3>
                <div class="form-group">
                  <label for="" class="col-8"><b>1. </b>  Teacher provided the course ouline having weekly content with list of required text book</label>
                  <input type="radio" name="q1" value="5" id="5"> <label for="5">5  |  </label>
                  <input type="radio" name="q1" value="4" id="4"> <label for="4">4  |  </label>
                  <input type="radio" name="q1" value="3" id="3"> <label for="3">3  |  </label>
                  <input type="radio" name="q1" value="2" id="2"> <label for="2">2  |  </label>
                  <input type="radio" name="q1" value="1" id="1"> <label for="1">1</label>
                </div>
                <div class="form-group">
                  <label for="" class="col-8"><b>2. </b>  Course Objective , learning ut come and grading criteria are clear to me</label>
                  <input type="radio" name="q2" value="5" id="5"> <label for="5">5  |  </label>
                  <input type="radio" name="q2" value="4" id="4"> <label for="4">4  |  </label>
                  <input type="radio" name="q2" value="3" id="3"> <label for="3">3  |  </label>
                  <input type="radio" name="q2" value="2" id="2"> <label for="2">2  |  </label>
                  <input type="radio" name="q2" value="1" id="1"> <label for="1">1</label>
                </div>
                <div class="form-group">
                  <label for="" class="col-8"><b>3. </b>  Course Intergrate throretical course concepts with the real wolrd exeample</label>
                  <input type="radio" name="q3" value="5" id="5"> <label for="5">5  |  </label>
                  <input type="radio" name="q3" value="4" id="4"> <label for="4">4  |  </label>
                  <input type="radio" name="q3" value="3" id="3"> <label for="3">3  |  </label>
                  <input type="radio" name="q3" value="2" id="2"> <label for="2">2  |  </label>
                  <input type="radio" name="q3" value="1" id="1"> <label for="1">1</label>
                </div>

                <div class="form-group">
                  <h3 class="my-4 font-weight-bold">2. Calss Teachning</h3>
                  <label for="" class="col-8"><b>4. </b>  Teacher is Punctual, Arriver on timee and leves on time</label>
                  <input type="radio" name="q4" value="5" id="5"> <label for="5">5  |  </label>
                  <input type="radio" name="q4" value="4" id="4"> <label for="4">4  |  </label>
                  <input type="radio" name="q4" value="3" id="3"> <label for="3">3  |  </label>
                  <input type="radio" name="q4" value="2" id="2"> <label for="2">2  |  </label>
                  <input type="radio" name="q4" value="1" id="1"> <label for="1">1</label>
                </div>

                <div class="form-group">
                  <label for="" class="col-8"><b>5. </b> Teacher is good at stimulating the interest in the course content</label>
                  <input type="radio" name="q5" value="5" id="5"> <label for="5">5  |  </label>
                  <input type="radio" name="q5" value="4" id="4"> <label for="4">4  |  </label>
                  <input type="radio" name="q5" value="3" id="3"> <label for="3">3  |  </label>
                  <input type="radio" name="q5" value="2" id="2"> <label for="2">2  |  </label>
                  <input type="radio" name="q5" value="1" id="1"> <label for="1">1</label>
                </div>

                <div class="form-group">
                  <label for="" class="col-8"><b>6. </b> Teacher is at expalaining the subject matter</label>
                  <input type="radio" name="q6" value="5" id="5"> <label for="5">5  |  </label>
                  <input type="radio" name="q6" value="4" id="4"> <label for="4">4  |  </label>
                  <input type="radio" name="q6" value="3" id="3"> <label for="3">3  |  </label>
                  <input type="radio" name="q6" value="2" id="2"> <label for="2">2  |  </label>
                  <input type="radio" name="q6" value="1" id="1"> <label for="1">1</label>
                </div>

                <div class="form-group">
                  <label for="" class="col-8"><b>7. </b>  Teacher's Presentation was clear loud and easy to undstand</label>
                  <input type="radio" name="q7" value="5" id="5"> <label for="5">5  |  </label>
                  <input type="radio" name="q7" value="4" id="4"> <label for="4">4  |  </label>
                  <input type="radio" name="q7" value="3" id="3"> <label for="3">3  |  </label>
                  <input type="radio" name="q7" value="2" id="2"> <label for="2">2  |  </label>
                  <input type="radio" name="q7" value="1" id="1"> <label for="1">1</label>
                </div>

                <div class="form-group">
                  <label for="" class="col-8"><b>8. </b> Teacher is good at using innovation teaching methods / way</label>
                  <input type="radio" name="q8" value="5" id="5"> <label for="5">5  |  </label>
                  <input type="radio" name="q8" value="4" id="4"> <label for="4">4  |  </label>
                  <input type="radio" name="q8" value="3" id="3"> <label for="3">3  |  </label>
                  <input type="radio" name="q8" value="2" id="2"> <label for="2">2  |  </label>
                  <input type="radio" name="q8" value="1" id="1"> <label for="1">1</label>
                </div>

                <div class="form-group">
                  <label for="" class="col-8"><b>9. </b> Teacher is available and helpful during counseling hours</label>
                  <input type="radio" name="q9" value="5" id="5"> <label for="5">5  |  </label>
                  <input type="radio" name="q9" value="4" id="4"> <label for="4">4  |  </label>
                  <input type="radio" name="q9" value="3" id="3"> <label for="3">3  |  </label>
                  <input type="radio" name="q9" value="2" id="2"> <label for="2">2  |  </label>
                  <input type="radio" name="q9" value="1" id="1"> <label for="1">1</label>
                </div>

                <div class="form-group">
                  <label for="" class="col-8"><b>10. </b>Teacher has completed the whole course as per the course outline</label>
                  <input type="radio" name="xys" value="5" id="5"> <label for="5">5  |  </label>
                  <input type="radio" name="xys" value="4" id="4"> <label for="4">4  |  </label>
                  <input type="radio" name="xys" value="3" id="3"> <label for="3">3  |  </label>
                  <input type="radio" name="xys" value="2" id="2"> <label for="2">2  |  </label>
                  <input type="radio" name="xys" value="1" id="1"> <label for="1">1</label>
                </div>


                <h3 class="my-4 font-weight-bold">3. Class Assessment</h3>
                <div class="form-group">
                  <label for="" class="col-8"><b>11. </b>Teacher was always fair and impartial</label>
                  <input type="radio" name="q11" value="5" id="5"> <label for="5">5  |  </label>
                  <input type="radio" name="q11" value="4" id="4"> <label for="4">4  |  </label>
                  <input type="radio" name="q11" value="3" id="3"> <label for="3">3  |  </label>
                  <input type="radio" name="q11" value="2" id="2"> <label for="2">2  |  </label>
                  <input type="radio" name="q11" value="1" id="1"> <label for="1">1</label>
                </div>

                <div class="form-group">
                  <label for="" class="col-8"><b>12. </b>Assessment conducted are clearly connected to maximize learning objective</label>
                  <input type="radio" name="q12" value="5" id="5"> <label for="5">5  |  </label>
                  <input type="radio" name="q12" value="4" id="4"> <label for="4">4  |  </label>
                  <input type="radio" name="q12" value="3" id="3"> <label for="3">3  |  </label>
                  <input type="radio" name="q12" value="2" id="2"> <label for="2">2  |  </label>
                  <input type="radio" name="q12" value="1" id="1"> <label for="1">1</label>
                </div>

                <div class="form-group">
                  <label for="" class="col-12"><b>13. </b>What I Liked about the Course</label>
                  <textarea name="q13" class="form-control col-10" rows="8" cols="50"></textarea>
                </div>

                <div class="form-group">
                  <label for="" class="col-12"><b>14. </b>What I disliked about the Course</label>
                  <textarea name="q14" class="form-control col-10" rows="8" cols="50"></textarea>
                </div>

                <div class="form-group col-10">
                  <input type="submit" class="btn btn-primary font-weight-bold btn-block " name="feedbacksubmit" value="Submit the Feed back">
                </div>

            </form>
            <?php
          } else {
            echo "<h2 class='font-weight-bold text-center'>Thank Your Feed back is submitted</h2>";
          }


           ?>

        </div>
      </div>
    </div>




    <!-- Footer Start -->
    <?php include 'inc/footer_inc.php'; ?>
    <!-- Footer Ends -->

<?php
}



 ?>

<?php
session_start();
if (!isset($_SESSION['name'])) {
  header("Location: ../index.php");
} else {
  echo'';
?>

    <!-- Header Start-->
    <?php include 'inc/header_inc.php'; ?>
    <!-- Header Ends -->
    <!-- Nav Bar Start-->
    <?php include 'inc/navbar_inc.php'; ?>
    <!-- Nav Bar Ends -->



    <div class="container-fulid">
      <div class="row p-0 m-0">
        <div class="col-lg-3 col-md-3 col-sm-3 p-0">
          <p class="h3 font-weight-bold text-light bg-primary text-center p-2 my-2">Dashboard</p>
          <div class="w-50 mx-auto">
            <img src="../img/profile/<?php echo $_SESSION['profile']; ?>" class="img img-thumbnail w-100" alt="">
          </div>
          <div class="p-3">
          <p class="font-weight-bold h4 text-center"> Name of the User</p>
          <a href="updatepassword.php" class="link btn btn-primary btn-block"><span><i class="fa fa-pencil" aria-hidden="true"></i> </span> <b>Update Password</b> </a>
          <a href="veiwuser.php" class="link btn btn-primary btn-block"><span><i class="fas fa-user" aria-hidden="true"></i> </span> <b>Manage User</b> </a>
          <a href="addnotification.php" class="link btn btn-primary btn-block"><span><i class="fas fa-user" aria-hidden="true"></i> </span> <b>Manage Notification</b> </a>
          <a href="feedback.php" class="link btn btn-primary btn-block"><span><i class="fa fa-thumbs-up" aria-hidden="true"></i> </span> <b>Feedback</b> </a>

        </div>

        </div>
        <div class="col-lg-9 col-md-9 col-sm-9 p-3">
          <?php
          if (isset($_GET['msg'])) {
           echo "<h2 class='text-center text-capitalize font-weight-bold'>";
           echo $_GET['msg'];
           echo "</h2>";
          }

           ?>
          <p class="h3 font-weight-bold text-dark p-2 my-2">All Notice</p>
          <table class="table table-hover table-striped">
            <tr class="table-primary">
              <th>Sr No.</th>
              <th>Subject</th>
              <th>Details</th>
              <th>User Name</th>
              <th>Date</th>
              <th>Action</th>
            </tr>
            <?php
            include '../dbh.php';
            $sql ='Select * from notice order by id desc';
            $result =mysqli_query($conn,$sql);
            $i =1;
            while ($row = mysqli_fetch_assoc($result)) {
              $srno=$i;
              $id=$row['id'];
              $subject=$row['subject'];
              $decs=$row['decs'];
              $username= $row['name'];
              $c_date=$row['c_date'];
              $link =   '<a href="delete_notice.php?id='.$id.'"> <i class="fa fa-trash"></i></a> / <a href="update_notice.php?id='.$id.'"><i class="fa fa-pencil" aria-hidden="true"></i> </a>';
              echo "
              <tr class=''>
              <td>$srno</td>
              <td>$subject</td>
              <td>$decs</td>
              <td>$username</td>
              <td>$c_date</td>
              <td>$link</td>
              </tr>
              ";
              $i++;
              }
             ?>
          </table>
        </div>
      </div>
    </div>




    <!-- Footer Start -->
    <?php include 'inc/footer_inc.php'; ?>
    <!-- Footer Ends -->

<?php
}



 ?>

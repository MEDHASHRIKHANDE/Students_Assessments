<?php
if (isset($_POST['feedbacksubmit'])) {
session_start();


  $user_name =$_SESSION['name'];
  $facility_name =$_POST['facility_name'];
  $q1 =$_POST['q1'];
  $q2 =$_POST['q2'];
  $q3 =$_POST['q3'];
  $q4 =$_POST['q4'];
  $q5 =$_POST['q5'];
  $q6 =$_POST['q6'];
  $q7 =$_POST['q7'];
  $q8 =$_POST['q8'];
  $q9 =$_POST['q9'];
  $q10 =$_REQUEST['xys'];
  $q11 =$_POST['q11'];
  $q12 =$_POST['q12'];
  $q13 =$_POST['q13'];
  $q14 =$_POST['q14'];
  $average_rating =round(($q1+$q2+$q3+$q4+$q5+$q6+$q7+$q8+$q8+$q9+$q10+$q11+$q12)/12);
  $cdate = date('d-m-Y');


  $sql ="insert into feedback values (null, '$user_name', '$facility_name', $q1, $q2, $q3, $q4, $q5, $q6, $q7, $q8, $q9, $q10, $q11, $q12, '$q13', '$q14', $average_rating, '$cdate')";
  include '../dbh.php';
  $result = mysqli_query($conn,$sql);
  if ($result) {
      header('Loaction: feedback.php?msg = Feedback Submited your data is secure with us');
      $_SESSION['feedback'] = "feedback";
  } else {
    header('Loaction: feedback.php?msg = Data not Submitted');
  }

} else {
  header('Loaction: feedback.php?msg= Error');
}




 ?>

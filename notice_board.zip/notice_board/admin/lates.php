<?php
session_start();
if (!isset($_SESSION['name'])) {
  header("Location: ../index.php");
} else {
  echo'';
?>

    <!-- Header Start-->
    <?php include 'inc/header_inc.php'; ?>
    <!-- Header Ends -->
    <!-- Nav Bar Start-->
    <?php include 'inc/navbar_inc.php'; ?>
    <!-- Nav Bar Ends -->



    <div class="container-fulid">
      <div class="row p-0 m-0">
        <div class="col-lg-3 col-md-3 col-sm-3 p-0">
          <p class="h3 font-weight-bold text-light bg-primary text-center p-2 my-2">Dashboard</p>
          <div class="w-50 mx-auto">
            <img src="../img/profile/<?php echo $_SESSION['profile']; ?>" class="img img-thumbnail w-100" alt="">
          </div>
          <div class="p-3">
          <p class="font-weight-bold h4 text-center"> Name of the User</p>
          <a href="updatepassword.php" class="link btn btn-primary btn-block"><span><i class="fa fa-pencil" aria-hidden="true"></i> </span> <b>Update Password</b> </a>
          <a href="veiwuser.php" class="link btn btn-primary btn-block"><span><i class="fas fa-user" aria-hidden="true"></i> </span> <b>Manage User</b> </a>
          <a href="addnotification.php" class="link btn btn-primary btn-block"><span><i class="fas fa-user" aria-hidden="true"></i> </span> <b>Manage Notification</b> </a>
          <a href="feedback.php" class="link btn btn-primary btn-block"><span><i class="fa fa-thumbs-up" aria-hidden="true"></i> </span> <b>Feedback</b> </a>

        </div>

        </div>
        <div class="col-lg-9 col-md-9 col-sm-9 p-3">
          <?php
          if (isset($_GET['msg'])) {
           echo "<h2 class='text-center text-capitalize font-weight-bold'>";
           echo $_GET['msg'];
           echo "</h2>";
          }

           ?>
          <p class="h3 font-weight-bold text-center text-dark p-2 my-2">Post News</p>
          <div class="">
            <form class="" action="news_hanlder.php" method="post">
              <div class="form-group">
                <input type="text" class="form-control" name="username" value="<?php echo $_SESSION['name'] ?>" placeholder="User Name">
              </div>
              <div class="form-group">
                <textarea name="news" class="form-control" rows="4" placeholder="News " cols="80" maxlength="200"></textarea>
                <p class="mx-3 text-muted">Maximum lenth of news 200</p>
              </div>
              <div class="form-group">
                <input type="text" class="form-control" name="author" value="" placeholder="Author Name">
              </div>
              <div class="form-group">
                <input type="submit" class="btn font-weight-bold btn-primary btn-block" name="submit_new" value="Submit News" placeholder="Author Name">
              </div>

            </form>
          </div>
        </div>
      </div>
    </div>




    <!-- Footer Start -->
    <?php include 'inc/footer_inc.php'; ?>
    <!-- Footer Ends -->

<?php
}



 ?>

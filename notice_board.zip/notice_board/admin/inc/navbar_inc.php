<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <a class="navbar-brand" href="dashboard.php" class="font-weight-bold"><b>Welcome <?php echo $_SESSION['name']; ?></b></a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav mr-auto">
        <li class="nav-item active">
          <a class="nav-link font-weight-bold" href="dashboard.php">Home </a>
        </li>
        <li class="nav-item active">
          <a class="nav-link font-weight-bold" href="addnotification.php">Add Notification</a>
        </li>
        <li class="nav-item active">
          <a class="nav-link font-weight-bold" href="lates.php">All Lates New</a>
        </li>
        <li class="nav-item active">
          <a class="nav-link font-weight-bold" href="feedback.php">Add Feedback</a>
        </li>

      </ul>

      <a href="logout.php" class="btn bg-danger font-weight-bold text-light mx-1"><span><i class="fas fa-lock"> </i></span> Log out</a>


    </div>
  </nav>

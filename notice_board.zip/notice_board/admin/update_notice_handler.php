<?php
if (isset($_POST['updatenotice'])) {
  session_start();
  $id=$_POST['id'];
  $subject=$_POST['subject'];
  $decs=$_POST['decs'];
  $sql ="select * from notice where id =$id";
  include '../dbh.php';
  $result = mysqli_query($conn, $sql);
  $count= mysqli_num_rows($result);
  if ($count > 0) {
    $row= mysqli_fetch_assoc($result);
    $sql="update notice set subject='$subject', decs='$decs' where id=$id";
    $result = mysqli_query($conn, $sql);

    if ($result) {
      header('Location: dashboard.php?msg=Password Update Success');
    } else {
      header('Location: dashboard.php?msg=Error in Password not update Pls Contact Admin');
    }


  } else {
    header('Location: dashboard.php?msg=Error in updateing the Password Pls Contact Admin');
  }

} else {
  header('Location: update_notice.php?msg=Error');
}



 ?>

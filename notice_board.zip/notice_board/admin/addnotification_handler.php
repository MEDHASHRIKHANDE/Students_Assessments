<?php
  if (isset($_POST['addnotice'])) {
    $subject = $_POST['subject'];
    $decs = $_POST['decs'];
    $c_date = date('d-m-Y');
    $name =$_POST['name'];
    include '../dbh.php';
    $sql="insert into notice values(null,'$subject','$decs','$c_date','$c_date','$name')";
    $result = mysqli_query($conn,$sql);
    if ($result) {
      header('Location: addnotification.php?msg=Notice Sented');
    } else {
      header('Location: addnotification.php?msg=Error Pls Contact Admin');
    }

  } else {
    header('Location: addnotification.php?msg=Error');
  }


 ?>

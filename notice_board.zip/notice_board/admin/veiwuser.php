<?php
session_start();
if (!isset($_SESSION['name'])) {
  header("Location: ../index.php");
} else {
  include '../dbh.php';

  echo'';
?>

    <!-- Header Start-->
    <?php include 'inc/header_inc.php'; ?>
    <!-- Header Ends -->
    <!-- Nav Bar Start-->
    <?php include 'inc/navbar_inc.php'; ?>
    <!-- Nav Bar Ends -->


    <div class="container-fulid">
      <div class="row p-0 m-0">
        <div class="col-lg-3 col-md-3 col-sm-3 p-0">
          <p class="h3 font-weight-bold text-light bg-primary text-center p-2 my-2">Dashboard</p>
          <div class="w-50 mx-auto">
            <img src="../img/profile/<?php echo $_SESSION['profile']; ?>" class="img img-thumbnail w-100" alt="">
          </div>
          <div class="p-3">
          <p class="font-weight-bold h4 text-center"> Name of the User</p>
          <a href="updatepassword.php" class="link btn btn-primary btn-block"><span><i class="fa fa-pencil" aria-hidden="true"></i> </span> <b>Update Password</b> </a>
          <a href="veiwuser.php" class="link btn btn-primary btn-block"><span><i class="fas fa-user" aria-hidden="true"></i> </span> <b>Manage User</b> </a>
          <a href="addnotification.php" class="link btn btn-primary btn-block"><span><i class="fas fa-user" aria-hidden="true"></i> </span> <b>Manage Notification</b> </a>
          <a href="feedback.php" class="link btn btn-primary btn-block"><span><i class="fa fa-thumbs-up" aria-hidden="true"></i> </span> <b>Feedback</b> </a>
        </div>

        </div>
        <div class="col-lg-9 col-md-9 col-sm-9 p-3">
          <?php
          if (isset($_GET['msg'])) {
           echo "<h2 class='text-center text-capitalize font-weight-bold'>";
           echo $_GET['msg'];
           echo "</h2>";
          }

           ?>
          <p class="h3 font-weight-bold text-dark p-2 my-2">All User To Website</p>
          <?php
          $sql="select * from signup order by id desc";
          $result=mysqli_query($conn,$sql);
          while ($row= mysqli_fetch_assoc($result)) {
            $id=$row['id'];
            echo '
            <div class="card float-left m-1" style="width: 19rem;">
            <img src="../img/profile/'.$row['profile'].'" class="card-img-top" alt="...">
            <div class="card-body">
            <h5 class="card-title font-weight-bold">User Details</h5>
              <ul class="list-group list-group-flush" style="line-height:5px;">
                <li class="list-group-item text-left"> <span class="font-weight-bold"> Name : </span>'.$row['name'].' </li>
                <li class="list-group-item text-left"> <span class="font-weight-bold"> Dob : </span>'.$row['dob'].' </li>
                <li class="list-group-item text-left"> <span class="font-weight-bold"> Mobile : </span>'.$row['mobile'].' </li>
                <li class="list-group-item text-left"> <span class="font-weight-bold"> Gender : </span>'.$row['gender'].' </li>
                <li class="list-group-item text-left"> <a href="delet_user_admin.php?id='.$id.'" class="btn btn-block btn-danger font-weight-bold"> <i class="fa fa-trash"></i> &nbsp;Delete User</a> </li>
              </ul>
            </div>
            </div>

            ';
          }


           ?>
        </div>
      </div>
    </div>




    <!-- Footer Start -->
    <?php include 'inc/footer_inc.php'; ?>
    <!-- Footer Ends -->

<?php
}



 ?>

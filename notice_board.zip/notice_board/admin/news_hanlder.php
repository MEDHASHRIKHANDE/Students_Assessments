<?php
if (isset($_POST['submit_new'])) {
  $username = $_POST['username'];
  $news = $_POST['news'];
  $author = $_POST['author'];

  $sql ="insert into news values(null,'$username','$news','$author')";
  include '../dbh.php';
  $result=mysqli_query($conn,$sql);
  if ($result) {
    header('Location: lates.php?msg=Success to uplaod News');
  } else {
    header('Location: lates.php?msg=Error');
  }

} else {
  header('Location: lates.php?msg=ERROR');
}



 ?>

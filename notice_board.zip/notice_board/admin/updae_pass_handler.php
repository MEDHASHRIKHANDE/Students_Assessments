<?php
if (isset($_POST['update_password_submit'])) {
  session_start();
  $id=$_SESSION['id'];
  $old_password=$_POST['old_password'];
  $upd_password=$_POST['new_password'];
  $sql ="select * from signup where id ='$id' and pass='$old_password'";
  include '../dbh.php';
  $result = mysqli_query($conn, $sql);
  $count= mysqli_num_rows($result);
  if ($count >= 0) {
    $row= mysqli_fetch_assoc($result);
    $db_pass=$row['pass'];
    $sql="update signup set pass='$upd_password' where id='$id'";
    $result = mysqli_query($conn, $sql);
    if ($result) {
      header('Location: updatepassword.php?msg=Password Update Success');
    } else {
      header('Location: updatepassword.php?msg=Error in Password not update Pls Contact Admin');
    }


  } else {
    header('Location: updatepassword.php?msg=Error in updateing the Password Pls Contact Admin');
  }

} else {
  header('Location: updatepassword.php?msg=Error');
}



 ?>

<?php
$id=$_GET['id'];
echo $id;
include '../dbh.php';
$sql ="delete from notice where id=$id";
$result= mysqli_query($conn,$sql);
if ($result) {
  header('Location: dashboard.php?msg= Data is Deleted');
} else {
  header('Location: dashboard.php?msg= Error while Data is Deleting');
}





 ?>

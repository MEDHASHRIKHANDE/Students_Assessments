<?php
session_start();
if (isset($_SESSION['name'])) {
  if ($_SESSION['name']=='kirdar') {
    $id=$_GET['id'];
    $sql ="DELETE FROM `signup` WHERE id =$id";
    include '../dbh.php';
    $result = mysqli_query($conn, $sql);
    if ($result) {
      header('Location: veiwuser.php?msg=User Delete Successfully');
    } else {
      header('Location: veiwuser.php?msg=Error Wile Deleting');
    }

  } else {
    header('Location:dashboard.php?msg=Error');
  }

}else {
  header('Location: veiwuser.php?msg=Error');
}



 ?>

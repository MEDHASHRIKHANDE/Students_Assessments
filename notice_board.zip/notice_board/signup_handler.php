<?php
if (isset($_POST['submit'])) {
  $name = $_POST['name'];
  $email = $_POST['email'];
  $pass= $_POST['password'];
  $mobile= $_POST['mobile'];
  $gender= $_POST['gender'];
  $dob = $_POST['dob'];
  $file = $_FILES['img'];
  $filename = $file['name'];
  $file_tmp_name = $file['tmp_name'];
  $folder = "img/profile/";
  $filenewname = time().$filename;
  $move = move_uploaded_file($file_tmp_name,$folder.$filenewname);

  if ($move) {
    include 'dbh.php';
    $sql = "insert into signup values(null,'$name','$email','$pass','$mobile','$gender','$filenewname','$dob')";
    $result = mysqli_query($conn,$sql);
    if ($result) {
      header('Location:login.php');
    } else {
      header('Location:signup.php?msg=Error');
    }


  } else {
    header('Location:signup.php?msg=Error in file');
  }




} else {
  echo "False";
}


 ?>

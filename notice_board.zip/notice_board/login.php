<!-- Header Start-->
<?php include 'inc/header_inc.php'; ?>
<!-- Header Ends -->
<!-- Nav Bar Start-->
<?php include 'inc/navbar_inc.php'; ?>
<!-- Nav Bar Ends -->
<!-- Silder Start -->
<?php include 'inc/slider_inc.php'; ?>
<!-- Silder Ends -->

<div class="container">
  <div class="card p-5">
    <form class="" action="login_handler.php" method="post">
      <p class="h3 my-3">Login Form</p>
      <div class="form-group">
        <input type="text" name="user_email"  placeholder="Email" class="form-control form-control-lg" required value="">
      </div>
      <div class="form-group">
        <input type="password" name="user_password"  placeholder="Password" class="form-control form-control-lg" required value="">
      </div>
      <div class="form-group">
        <input type="submit" name="login_submit" value="Login" class="btn-lg btn-primary btn-block" value="">
      </div>
    </form>
  </div>
</div>


<!-- Footer Start -->
<?php include 'inc/footer_inc.php'; ?>
<!-- Footer Ends  -->

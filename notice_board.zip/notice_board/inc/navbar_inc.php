<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <a class="navbar-brand" href="index.php">Navbar</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav mr-auto">
        <li class="nav-item active">
          <a class="nav-link font-weight-bold" href="index.php">Home </a>
        </li>
        <li class="nav-item active">
          <a class="nav-link" href="about.php">About us</a>
        </li>
        <li class="nav-item active">
          <a class="nav-link" href="lates.php">All Lates New</a>
        </li>
        <li class="nav-item active">
          <a class="nav-link" href="contact.php">Contact</a>
        </li>

      </ul>

      <a href="signup.php" class="btn btn-light font-weight-bold text-primary mx-1"><span><i class="fa fa-user" aria-hidden="true"></i> </span> Sign Up</a>
      <a href="login.php" class="btn btn-light font-weight-bold text-primary mx-1"><span><i class="fas fa-file"> </i></span> Login</a>


    </div>
  </nav>

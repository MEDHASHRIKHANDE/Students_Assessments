<?php
if(isset($_POST['login_submit'])){
  include 'dbh.php';
  $user_email =$_POST['user_email'];
  $user_password =$_POST['user_password'];

  $sql="select * from signup where email ='$user_email' AND pass = '$user_password'";
  $result = mysqli_query($conn,$sql);
  $count = mysqli_num_rows($result);
if ($count > 0) {
  $row = mysqli_fetch_assoc($result);
  $db_email = $row['email'];
  $db_password = $row['pass'];

  if ($user_email === $db_email && $user_password === $db_password) {
    session_start();
    $_SESSION['id']=$row['id'];
    $_SESSION['name']=$row['name'];
    $_SESSION['profile']=$row['profile'];

    header("Location: admin/dashboard.php");

  } else {
    header("Location: login.php?msg= email or Password invalid");
  }


}else {
  header("Location: login.php?msg= No User found or Password invalid");
}

}else {
  header("Location: login.php?msg= Error");
}


 ?>

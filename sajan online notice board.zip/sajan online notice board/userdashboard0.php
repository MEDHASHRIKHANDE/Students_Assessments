<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="css/bootstrap.css"/>
		<script src="js/jquery_library.js"></script>
<script src="js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  </head>
  <body>
    <?php
    session_start();
    $op=$_SESSION['name'];
    echo $op;
  include 'dhp.php';
  $sql="select * from user where name='".$op."'";
    $result=mysqli_query($conn,$sql);
    $record=mysqli_fetch_assoc($result);
    $db_password=$record['password'];
     ?>
    <div class="container-fulid ">
      <nav class="navbar navbar-default navbar-fixed-top" style="background:#000">
        <div class="container">
        <ul class="nav navbar-nav navbar-left">
          <li><a href="" style="color:white"><strong>Hello <?php echo $_SESSION['name'] ?></strong></a></li>
      	</ul>
      <ul class="nav navbar-nav navbar-right">
            <li><a href="logout.php" style="color:white"><span class="glyphicon glyphicon-user"></span> Logout</a></li>
          </ul>
      </div>
    </nav>
  </div><br><br>
      <div class="row">
        <div class="col-lg-3 lg-text-center">
            <h3 class="bg-info">User Profile</h3><br>
          <img src="images/person.jpg">
          <a href="changepassword.php" class="fa fa-key"> change password</a><br><br>
          <a href="update_profile.php"  class="fa fa-user"> update profile</a><br><br>
          <a href="notification.php" class="fa fa-bell"> notifaction</a><br><br>
        </div>
      </div>
  </body>
</html>

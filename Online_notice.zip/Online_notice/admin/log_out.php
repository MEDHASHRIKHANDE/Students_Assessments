<?php
  $conn = mysqli_connect("localhost","root","","notice");
  if($conn == True && isset($_POST['logout'])){
    session_start();
    session_destroy($_SESSION['name']);
  }
  else{
    header('Location: login.php?msg=logout');
  }
 ?>

<?php
session_start();
  include 'dhp.php';
  if($conn){

$user=$_POST['user'];
  $password=$_POST['pass'];
$sql="update admin set pass='$password' where user='$user'";
$result=mysqli_query($conn,$sql);
if($result){
header ('location:login1.php');

}

else{

echo"not updated";
}
}
else{

echo"error";
}


















 ?>

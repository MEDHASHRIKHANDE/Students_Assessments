<?php

if(isset ($_REQUEST['login'])){


  $email=$_REQUEST['email'];
  $password=$_REQUEST['password'];
  include 'dhp.php';


  $sql="select * from user where email='".$email."'";

  $result=mysqli_query($conn,$sql);
$row= mysqli_num_rows($result);
if($row >0)
{

  $record=mysqli_fetch_assoc($result);
  $db_email=$record['email'];
  $db_password=$record['password'];

  if($email===$db_email && $password===$db_password){
session_start();
$_SESSION['name']=$record['name'];

   header('Location:userdashboard.php');

  }
  else{
     header('Location:login.php?msg=invalid username or password');
  }


}
else{
   header('Location:registration.php?msg=<h1>please register account here</h1>');
}
}
else{

  header('Location:registration.php?msg=<h1>ERROR</h1>');
}

















 ?>

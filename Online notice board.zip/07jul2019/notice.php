<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="card mt-3 p-3">
            <h5>latest news</h5>
            <div class="card body mt-3 p-3">
              <h6>this is best website you can search any thing here <br>the best website </h6>

                </div>
          </div>
        </div>
      </div>
        </div>
          </body>
</html>

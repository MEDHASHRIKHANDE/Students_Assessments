<?php
$conn=mysqli_connect("localhost","root","","online notice");
if ($conn)
 {
  $username=$_REQUEST['username'];
  $password=$_REQUEST['password'];
  $dob =$_REQUEST['dob'];
  $email=$_POST['email'];
  $mobile=$_POST['mobile'];
  $gender=$_POST['gender'];
  $hobbies=$_POST['hobbies'];
  $uploadprofile=$_POST['uploadprofile'];


  $sql="insert into signup values(null,'".$username."','".$password."','".$dob."','".$email."','".$mobile."','".$gender."','".$hobbies."','".$uploadprofile."')";
   $result=mysqli_query($conn,$sql);

  if ($result)
  {

    header('Location:dashboard.php');
  }
   else {
         echo "account not created ";
   }
 }
 else {
   echo "not connected";
 }
 ?>

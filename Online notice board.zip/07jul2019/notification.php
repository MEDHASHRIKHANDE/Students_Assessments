<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

  </head>
  <body>
    <div class="row">
      <div class="col-lg-12">
        <table class="table">
          <tr>
            <th style="width: 50px">sr.no</th>
            <th style="width:150px">subject</th>
            <th style="width:450">details</th>
            <th style="width:200">date</th>
          </tr>
          <?php
             $conn=mysqli_connect("localhost","root","","online notice");
             session_start();
             $user = $_SESSION['name'];
             $qry = "select *from adminnotification where user='$user'";
             $res = mysqli_query($conn,$qry);
             $row = mysqli_affected_rows($conn);
             if($res == True){
               $i = 1;
               while($row = mysqli_fetch_assoc($res)){
                 echo "<tr>";
                 echo "<td>".$i."</td>";
                 echo "<td>".$row['subject']."</td>";
                 echo "<td>".$row['details']."</td>";
                 echo "<td>".$row['date']."</td>";
                 echo "</tr>";
                 $i++;
               }
             }
           ?>
        </table>
      </div>

    </div

  </body>
</html>

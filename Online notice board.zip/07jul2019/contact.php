<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <div class="row mt-3 p-3">
      <div class="col-lg-12">
        <div class="card text-center">
          <h1>contact us</h1>
          <div class="card body text-center p-3">
            <h4>Name:urmila satam <br>
                Mobile :8898469520 <br>
                Email :urmi@gmail.com <br>
                website:phptpoint
             </h4>
          </div>
        </div>
      </div>
    </div>
  </body>
</html>

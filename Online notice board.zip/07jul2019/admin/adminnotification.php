<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

  </head>
  <body>
    <div class="row">
      <div class="col-lg-12">
        <table class="table">
          <tr>
            <th style="width: 50px">sr.no</th>
            <th style="width:150px">subject</th>
            <th style="width:450">details</th>
            <th style="width:200">date</th>
          </tr>
          <?php
             $conn=mysqli_connect("localhost","root","","online notice");
          if ($conn) {
            $srno=$_REQUEST['sr.no'];
            $subject=$_REQUEST['subject'];
            $details=$_REQUEST['details'];
            $date=$_REQUEST['date'];

        $sql="insert into adminnotification values('".$srno."','".$subject."','".$details."','".$date."')";
        $result=mysqli_query($conn,$sql);

            if ($result) {
               
            } else {
              // code...
            }


          } else {
            // code...
          }

             $qry = "insert into adminnotification values('".$sr."')";
             $res = mysqli_query($conn,$qry);

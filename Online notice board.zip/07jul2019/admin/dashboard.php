<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


  </head>
  <body>
    <div class="container">
      <div class="row">
        <div class="col-lg-12 bg dark">
          <h1>hello</h1>
        </div>
      </div>
        </div>

     <div class="row ">
     <div class="col-lg-3">
       <h3>Dashboard</h3><br>
        <img  src="img/1521018917.png " alt=""><br>
        <a href="dashboard.php?option=updateprofile"><i class="fa fa-user" aria-hidden="true"></i>update profile</a> <br><br>
        <a href="dashboard.php?option=updatepassword"><i class="fa fa-user" aria-hidden="true"></i>Update password</a><br><br>
        <a href="dashboard.php?option=notification"><i class="fa fa-envelope-o" aria-hidden="true"></i>Notification</a><br><br>
       </div>



    <div class="col-lg-9">
       <?php
       if (isset($_GET['option'])) {
    $option=$_GET['option'];
     if ($option)
      {
        if ($option=='updatepassword')
         {
           include('updatepassword.php');
        }
        else if($option=='updateprofile')
      {
        include('updateprofile.php');

     }else if ($option=='notification'){
        include('notification.php');
      }

 }else{
}
 }

        ?>
  </div>
</div>

  </body>
</html>

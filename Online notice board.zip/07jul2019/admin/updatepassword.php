<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

  </head>
  <body>

      <div class="row">
        <div class="col-lg-12">
          <form class=""action="" method="post">

            <label>Enter Your age</label>
            <input type="int" name="age" value=""><br>

            <label>Enter Your new password</label>
            <input type="text" name="password" value=""><br>

            <label>Enter Your Confirm password</label>
            <input type="text" name="confirmpassword" value=""><br>

            <input type="submit" name="update password" value="update password">
            <input type="submit" name="Reset" value="Reset">

          </form>
        </div>
      </div>



    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" ></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" ></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" ></script>
  </body>
</html>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
       <form class="" action="signuphandler.php" method="post">

         <div class="container-fluid">
           <div class="container">
             <h1>sign up</h1><br><br>
             <div class="row">
                <div class="col-lg-5">
                 <label for="">Enter your Username</label>
                 </div>
                <div class="col-lg-7">
                  <input type="text" name="username" value="">
                </div>
             </div><br>

             <div class="row">
               <div class="col-lg-5">
                 <label for="">Enter your password</label>
                 </div>
                <div class="col-lg-7">
                  <input type="text" name="password" value="">
                </div>
             </div><br>
             <div class="row">
               <div class="col-lg-5">
                 <label for="">Enter your DOB</label>
                 </div>
                <div class="col-lg-7">
                  <input type="date" name="dob" value="">
                </div>
             </div><br>
             <div class="row">
               <div class="col-lg-5">
                 <label for="">Enter your Email id</label>
                 </div>
                <div class="col-lg-7">
                  <input type="email" name="email" value="">
                </div>
             </div><br>
             <div class="row">
               <div class="col-lg-5">
                 <label for="">Enter your Mobile No</label>
                 </div>
                <div class="col-lg-7">
                  <input type="tel" name="mobile" value="">
                </div>
             </div><br>
             <div class="row">
               <div class="col-lg-5">
                 <label for="">select your Gender  </label>
                 </div>
                <div class="col-lg-7">
                  <select class="" name="gender">
                    <option>choice</option>
                    <option>Female</option>
                    <option>Male</option>
                  </select>
                </div>
             </div><br>


             <div class="row">
               <div class="col-lg-5">
                 <label for="">choice your Hobbies</label>
                 </div>
                <div class="col-lg-7">
                  <select class="option" name="hobbies">
                    <option>choice</option>
                    <option>reading</option>
                    <option>cooking</option>
                    <option>swimming</option>
                  </select>
                </div>
             </div><br>


             <div class="row">
               <div class="col-lg-5">
                 <label for=""> Upload Profile</label>
                 </div>
                <div class="col-lg-7">
                  <select class="option" name="uploadprofile">
                    <option value="">choice</option>

                  </select>
                </div>
             </div><br>

            <div class="row">
              <div class="col-lg-4">
              </div>
              <div class="col-lg-4 text-center">
                <input class="btn btn-success" type="submit" name="signup" value="Sign up">
              </div>
              <div class="col-lg-4">
              </div>

            </div>

           </div>
         </div>
       </form>
  </body>
</html>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

  </head>
  <body>

    <form class="col-lg-12" action="dashboard.php" method="post">
      <h1 class="m-3 p-3">Login page</h1>
    <div class="row">
      <div class="col-lg-5">
        <p for="">Enter your Username</p>

      </div>
        <div class="col-lg-7">
            <input type="text" name="username" value=""  >
        </div>

    </div><br>


    <div class="row">
      <div class="col-lg-5">
        <p for="">Enter your password</p>

      </div>
        <div class="col-lg-7">
            <input type="text" name="password" value=" ">
        </div>

    </div> <br><br>

    <div class="row">
      <div class="col-lg-4">
      </div>

      <div class="col-lg-4 text-center">
        <input class="btn btn-success" type="submit" name="login" value="login">
      </div> <br><br>

      <div class="col-lg-4">
      </div>

    </div>


    </form>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" ></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" ></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" ></script>

  </body>
</html>

<?php
$conn= mysqli_connect("localhost","root","","online notice");
if (isset($_POST['login']))
{
  $username=$_POST['username'];
  $password=$_POST['password'];

  $sql="select * from adminlogin where username='$username'";
  $result=mysqli_query($conn,$sql);
  $row=mysqli_num_rows($result);
  if ($row>0)
  {
  $record=mysqli_fetch_assoc($result);
  $db_username=$record['username'];
  $db_password=$record['password'];

if ($username===$db_username && $password===$db_password)
  {
    session_start();
    $_SESSION['name']=$record['name'];
    header('Location: dashboard.php');
  }
  else {
    header('Location: loginform.php?msg=invalid username or password');
  }
}
else{
  header('Location:signup.php?msg=registerd your account here');
}

}
else{

  header('Location:signup.php?msg=error');


}


 ?>

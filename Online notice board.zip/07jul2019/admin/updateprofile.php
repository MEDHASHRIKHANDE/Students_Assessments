<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

  </head>
  <body>
    <form class="" action="index.html" method="post">
      <h1>Update Your profile</h1>
      <label>Enter Your Name</label>
      <input type="text" name="name" value=""> <br><br>

      <label>Enter Your email</label>
      <input type="email" name="email" value=""><br><br>

      <label>Enter Your Mobile </label>
      <input type="tel" name="mobile" value=""><br><br>

      <label>select Your Gender</label>
      <select class="option" name="gender">
        <option>choice</option>
        <option>female</option>
        <option>male</option>
      </select><br><br>


       <label>Choose Your hobbies</label>
       <input class="option" name="hobbies" value="">
       <option>reading</option>
       <option>swimming</option>
       <option>palying</option><br><br>

       <label>Enter Your dob</label>
       <input type="date" name="dob" value=""><br><br>


    </form>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" ></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" ></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" ></script>

  </body>
</html>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    </head>
  <body>
    <nav class="container-fluid navbar navbar-expand navbar-dark bg-dark sticky-top ">
      <div class="container">

          <ul class="nav navbar-nav">
            <li class="nav-item">
              <a class="nav-link" href="login.php">ONline notice board</a>
            </li>

            <li class="nav-item">
              <a class="nav-link" href="index.php?option=about"><i class="fa fa-user-o" aria-hidden="true"></i>About</a>
            </li>

             <li class="nav-item">
              <a class="nav-link" href="index.php?option=contact"><i class="fa fa-phone" aria-hidden="true"></i>Contact</a>
            </li>
            </ul>

              <ul class=" nav navbar navbar justify-contact-right navbar-dark bg-dark">
                <li class="nav-item">
              <a class="nav-link" href="index.php?option=signup"><i class="fa fa-user-circle" aria-hidden="true">Singup</i></a>
            </li>

            <li class="nav-item justify-contact-right">
              <a class="nav-link" href="index.php?option=login"><i class="fa fa-sign-in" aria-hidden="true"></i>Login</a>
            </li>
          </ul>
        </div>
    </nav>

        <div class="container-fluid">
          <div class="carousel slide" data-ride="carousel" id="mycarousel">
            <ol class="carousel-indicators">
               <li data-target="#mycarousel" data-slide-to="0" class="active"></li>
               <li data-target="#mycarousel" data-slide-to="1"></li>
            </ol>
            <div class="carousel-inner">
              <div class="carousel-item active">
                <img class="w-100" src="img/pbanner.jpg" alt="">
              </div>
              <div class="carousel-item">
                <img class="w-100 h-60" src="img/new2.jpg" alt="">
              </div>
            </div>
            <a  class="carousel-control-prev" href="#mycarousel"role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" arial-hidden="true"></span>
            <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#mycarousel" role="button" data-slide="next">
              <span class="carousel-control-next-icon" arial-hideen="true"></span>
               <span class="sr-only">next</span>
            </a>
          </div>
        </div>

  <div class="container-fluid">
    <div class="container">
      <div class="row">
        <div class="col-lg-8">
          <?php
          if (isset($_GET['option'])) {
            // code...

          $option=$_GET['option'];
           if ($option)
            {
              if ($option=='about')
              {
                include('about.php');
              }
              else if($option =='contact')
               {
                 include('contact.php');

              }
                 elseif ($option=='signup')
                  {
                     include('signup.php');
                 }
                   elseif ($option=='login')
                   {
                     include('login.php');
                   }
           }
         }
            else
            {
               echo "welcome our online notice board ";
           }

           ?>
        </div>

    <div class="col-lg-4">
      <?php
      include('notice.php');
       ?>
    </div>

      </div>
    </div>
  </div>



      <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" ></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" ></script>
      <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" ></script>
     </body>
</html>

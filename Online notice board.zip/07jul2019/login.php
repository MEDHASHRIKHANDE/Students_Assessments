<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

  </head>
  <body>
    <div class="container">
    <form class="col-lg-12" action="dashboard.php" method="post">
      <h1 class="m-3">Admin Login page</h1>
    <div class="row">
      <div class="col-lg-4">
        <lable>Enter your Username</lable></div>
        <div class="col-lg-8">
            <input class="form-control" type="text" name="username" value=""></div></div><br>


    <div class="row">
      <div class="col-lg-4">
        <lable>Enter your password</lable></div>
        <div class="col-lg-8"><input class="form-control" type="text" name="password" value=" "></div></div> <br><br>

    <div class="row"><div class="col-lg-4">


      <div class="col-lg-4 text-center">
        <input class="btn btn-success" type="submit" name="login" value="login"></div>
      </div> <br><br>

      <div class="col-lg-4">
        
      </div>

    </div>


    </form>
    </div>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" ></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" ></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" ></script>

  </body>
</html>

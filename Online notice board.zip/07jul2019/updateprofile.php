<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

  </head>
  <body>
    <div class="container-fluid">
      <div class="container">
          <form class="mt-5" action="index.html" method="post">
            <h1 class="bg-info">Update Your profile</h1><br><br>
            <div class="row">
              <div class="col-lg-4"><label>Enter Your Name</label></div>
               <div class="col-lg-8"><input class="form-control" type="text" name="name" value=""></div>
            </div><br>

        <div class="row">
    <div class="col-lg-4">  <label>Enter Your email</label></div>
    <div class="col-lg-8">  <input class="form-control" type="email" name="email" value=""></div>
        </div><br>
      <div class="row">
    <div class="col-lg-4">  <label>Enter Your Mobile </label></div>
      <div class="col-lg-8"><input class="form-control" type="tel" name="mobile" value=""></div>
          </div><br>
        <div class="row">
    <div class="col-lg-4">  <label>select Your Gender</label></div>
    <div class="col-lg-8">  <select class="option" name="gender">
        <option class="form-control">choice</option>
        <option>female</option>
        <option>male</option>
      </select></div>
        </div><br>
      <div class="row">
      <div class="col-lg-4"> <label>Choose Your hobbies</label></div>
    <div class="col-lg-8">   <select class="option" name="">
         <option>playing</option>
         <option>singing</option>
         <option>Reading</option>
         <option>Dancing</option>
       </select></div>
     </div><br>


         <div class="row">
      <div class="col-lg-4"> <label>Enter Your dob</label></div>
      <div class="col-lg-8"> <input type="date" name="dob" value=""></div><br><br>
         </div>
           </div>
    </form>

</div>

    </div>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" ></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" ></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" ></script>

  </body>
</html>

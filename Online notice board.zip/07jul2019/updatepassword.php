<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

  </head>
  <body>

      <div class="container mt-5">
        <div class="col-lg-12">
              <h1>Update Password</h1><br><br>
          <form class=""action="" method="post">
           <div class="row">
          <div class="col-lg-4"><label>Enter Your age</label></div>
          <div class="col-lg-8"><input type="int" name="age" value=""></div>
           </div><br>

           <div class="row">
          <div class="col-lg-4">  <label>Enter Your new password</label></div>
            <div class="col-lg-8">  <input type="text" name="password" value=""></div>
            </div><br>

            <div class="row">
          <div class="col-lg-4">  <label>Enter Your Confirm password</label></div>
            <div class="col-lg-8">  <input type="text" name="confirmpassword" value=""></div>
            </div><br>

            <div class="row">
            <input  class="btn btn-info"type="submit" name="update password" value="update password">&nbsp;&nbsp;
            <input  class="btn btn-info"type="submit" name="Reset" value="Reset">
            </div>
          </form>
        </div>
      </div>



    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" ></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" ></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" ></script>
  </body>
</html>

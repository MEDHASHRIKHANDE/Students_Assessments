<?php
$conn =mysqli_connect('localhost','root','','noticeboard');

if ($conn) {
  $username=$_POST['username'];
  $password=$_POST['password'];
  $dob=$_POST['dob'];
  $email=$_POST['email'];
  $mobile=$_POST['mobile'];
  $gender=$_POST['gender'];
  $hobbies=$_POST['hobbies'];


  $sql="insert into signup values(null,'".$username."','".$password."','".$dob."','".$email."','".$mobile."','".$gender."','".$hobbies."',null)";

  $result=mysqli_query($conn,$sql);

  if ($result) {
    header('Location: onlinenotice.php?msg=ACCOUNT SUCCESSFULLY CREATED');
  }else {
    header('Location: onlinenotice.php?msg=ERROR');
  }

} else {
  // code...
}



 ?>

<?php
$conn = mysqli_connect('localhost','root','','noticeboard');


if (isset($_POST['update']))
{
  $username=$_POST['username'];
  $email=$_POST['email'];
  $mobile=$_POST['mobile'];

   $sql = "update signup set username='$username',mobile='$mobile' where email='$email'";

   $result=mysqli_query($conn,$sql);

   if ($result) {
     header ('Location: dashboard.php?MSG=SUCCESSFULLY UPDATED');

   } else {
     header('Location: dashboard.php?mseg=serever error');
   }

}
else
 {
  // code...
}

 ?>

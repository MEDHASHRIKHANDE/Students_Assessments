<?php
$conn =mysqli_connect('localhost','root','','noticeboard');
if (isset($_POST['login'])) {

  $username = $_POST['username'];
  $password = $_POST['password'];

  $sql = "select * from admin where username='".$username."'";

  $result =mysqli_query($conn,$sql);

  $row = mysqli_num_rows($result);
  if ($result) {
    $record = mysqli_fetch_assoc($result);
    $db_username= $record['username'];
    $db_password= $record['password'];


     if ($username===$db_username && $password===$db_password) {
       session_start();
       $_SESSION['name']=$record['username'];
       $user=$_SESSION['name'];

          header('Location: adashboard.php?option=managenotification');

     }
     else {
     header('Location: login.php?msg=Invalid username or password');
    }
  }

  else {
    header('Location: login.php?msg=ERROR ON ADMIN PAGE');
  }

} else {
  header('Location: login.php?msg=ERROR');
}




 ?>

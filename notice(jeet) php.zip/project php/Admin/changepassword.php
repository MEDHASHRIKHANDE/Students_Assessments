<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  </head>
  <body>
    <?php
    
  $user= $_SESSION['name'];
  $conn=mysqli_connect('localhost','root','','noticeboard');
  $sql= "select * from admin where username='$user'";

  $result = mysqli_query($conn,$sql);

  if ($result) {
    $record= mysqli_fetch_assoc($result);
    $old=$record['password'];
  } else {

  }

   ?>
    <form class="col-lg-12 mt-3" action="changepasswordhandler.php" method="post">
      <div class="row">
        <div class="col-lg-12 text-center">
        <h2>Change Your Password</h2>
        </div>
      </div>
      <br>
      <div class="row">
          <div class="col-lg-3">
            <h6>Enter Your old password:-</h6>
          </div>
          <div class="col-lg-9">
            <input class="form-control" type="text" name="password" value="<?php echo $old; ?>" readonly>
          </div>
        </div>
        <br>
        <div class="row">
            <div class="col-lg-3">
              <h6>Enter Your New password:-</h6>
            </div>
            <div class="col-lg-9">
              <input class="form-control" type="text" name="new" value="">
            </div>
          </div>
          <br>
          <div class="row">
              <div class="col-lg-3">
                <h6>Confirm New password:-</h6>
              </div>
              <div class="col-lg-9">
                <input class="form-control" type="text" name="new_pass" value="">
              </div>
            </div>
            <br>
            <div class="row">
              <div class="col-lg-4">

              </div>
              <div class="col-lg-4">
                <input class="btn btn-primary" type="submit" name="update" value="UPDATE">
                <input  class="btn btn-primary" type="submit" name="reset" value="RESET">
              </div>
              <div class="col-lg-4">

              </div>

            </div>
      </div>
    </form>

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" ></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" ></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" ></script>
  </body>
</html>

<?php
$conn=mysqli_connect('localhost','root','','noticeboard');
if (isset($_POST['submit'])) {
  $subject=$_POST['subject'];
  $details=$_POST['details'];
  $username=$_POST['username'];
  $date='SYSDATE()';
  $sql="insert into notice values(null,'$username','$subject','$details',$date)";

    $result=mysqli_query($conn,$sql);
  if ($result) {
    header('Location: adashboard.php?MSG=successfully added notice');
  } else {
    echo "error";
  }

}
else {
  echo "ERROR";
}

 ?>

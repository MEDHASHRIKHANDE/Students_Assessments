<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  </head>
  <body>
    <div class="container-fluid bg-dark p-3">
      <div class="row ">
        <div class="col-lg-2 text-left">
          <?php
          session_start();
          $user=$_SESSION['name'];
           ?>
        <h5 class="text-light">Welcome <?php echo  $user; ?> !</h5>
        </div>
        <div class="col-lg-10 text-right ">
          <a href="logout.php" class="text-light"><b>Logout</b></a>
        </div>
      </div>
    </div>

    <div class="container-fluid">
      <div class="row">
        <div class="col-lg-3">
          <a href="adashboard.php?option=Dashboard" class="btn mt-3 bg-primary p-3 text-center text-light">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Dashboard&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>
          <img src="img/userlogo.png" alt=""><br><br>
            <a href="adashboard.php?option=changepassword"><i class="fa fa-user" aria-hidden="true"></i>Manage password</a><br><br>
            <a href="adashboard.php?option=manageuser"><i class="fa fa-user" aria-hidden="true"></i>Manage User</a><br><br>
            <a href="adashboard.php?option=managenotification"><i class="fa fa-envelope" aria-hidden="true"></i>Manage Notification</a><br><br>
        </div>

        <div class="col-lg-9">
          <?php
            if (isset($_GET['option'])) {


            $option=$_GET['option'];
            if ($option)
             {
              if ($option=='changepassword')
               {
                include('changepassword.php');
              }
              elseif($option=='manageuser')
              {
                include('manageuser.php');

              }
              elseif ($option=='managenotification')
               {
                include('managenotification.php');
              }
              elseif ($option=='Dashboard') {
                include('maindashboard.php');
              }
            }
            }

            if (isset($_GET['MSG'])) {
              echo $_GET['MSG'];
            }
           ?>
        </div>

      </div>
    </div>


    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" ></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" ></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" ></script>
  </body>
</html>

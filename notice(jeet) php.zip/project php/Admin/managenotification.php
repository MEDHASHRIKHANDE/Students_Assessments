
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  </head>
  <body>

    <form class="" action="addnoticehandler.php" method="post">
      <div class="row mt-3">
        <div class="col-lg-12 text-center">
          <h2>Manage Notification</h2>
        </div>
      </div>
      <br>
      <div class="row">
        <div class="col-lg-3">
          <h5>Enter subject:</h5>
        </div>
        <div class="col-lg-9">
          <input class="form-control" type="text" name="subject" value="" placeholder="subject">
        </div>
      </div>
      <br>
      <div class="row">
        <div class="col-lg-3">
          <h5>Enter Details:</h5>
        </div>
        <div class="col-lg-9">
          <textarea class="form-control" name="details" value=""  rows="4" cols="80"></textarea>
        </div>
      </div>
      <br>
      <div class="row">
        <div class="col-lg-3">
          <h5>Enter Username:</h5>
        </div>
        <div class="col-lg-9">
          <select class="form-control" name="username" multiple="multiple">
            <?php
            $conn=mysqli_connect('localhost','root','','noticeboard');
            $sql="select username from signup";
            $result=mysqli_query($conn,$sql);
            while ($r= mysqli_fetch_assoc($result)) {
              echo "<option>".$r['username']."</option>";
            }

             ?>
          </select>
        </div>
      </div>
      <br>
      <div class="row">
        <div class="col-lg-12 text-center">
          <input class="btn btn-primary" type="submit" name="submit" value="Submit">
        </div>
      </div>
    </form>

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" ></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" ></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" ></script>
  </body>
</html>

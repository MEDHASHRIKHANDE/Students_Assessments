<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  </head>
  <body>
    <div class="container-fluid text-center" style="margin-top:150px;">
      <div class="container">
        <form action="loginhandler.php" method="post">
        <div class="row">
          <div class="col-lg-3">

          </div>
          <div style="border-radius:20px;" class=" col-lg-6 card bg-secondary text-light p-3" >
              <div class="row">
                <div class="col-lg-12 text-center">
                    <h1>Admin</h1>
                </div>
              </div>
              <br>
              <div class="row">
                <div class="col-lg-4">
                  <h6>Username:-</h6>
                </div>
                <div class="col-lg-8">
                  <input class="form-control" type="text" name="username" value="">
                </div>
              </div>
              <br>
              <div class="row">
                <div class="col-lg-4">
                  <h6>Password:-</h6>
                </div>
                <div class="col-lg-8">
                  <input class="form-control" type="password" name="password" value="">
                </div>
              </div>
              <br>
              <div class="row">
                <div class="col-lg-12 text-center">
                  <input class="btn btn-primary"type="submit" name="login" value="Login">
                </div>
              </div>
            </form>
          </div>
          <div class="col-lg-3">

          </div>
        </div>
      </div>

    </div>

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" ></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" ></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" ></script>
  </body>
</html>

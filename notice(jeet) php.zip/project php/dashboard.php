<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  </head>
  <body>
    <div class="container-fluid bg-dark p-3">
      <div class="row ">
        <div class="col-lg-2 text-left">
          <?php
          session_start();
          $user=$_SESSION['name'];
           ?>
        <h3 class="text-light">Hello <?php echo $user;?></h3>
        </div>
        <div class="col-lg-10 text-right mt-2">
          <a href="onlinenotice.php" class="text-light"><b>Logout</b></a>
        </div>
      </div>
    </div>

    <div class="container-fluid">
      <div class="row">
        <div class="col-lg-3">
          <h3 class="mt-3 bg-primary p-3 text-center">Dashboard</h3>
          <img src="img/userlogo.png" alt=""><br><br>
            <a href="dashboard.php?option=update_password"><i class="fa fa-user" aria-hidden="true"></i>Update password</a><br><br>
            <a href="dashboard.php?option=update_profile"><i class="fa fa-user" aria-hidden="true"></i>Update profile</a><br><br>
            <a href="dashboard.php?option=Notification"><i class="fa fa-envelope" aria-hidden="true"></i>Notification</a><br><br>
        </div>

        <div class="col-lg-9">
          <?php
            if (isset($_GET['option'])) {
            $option=$_GET['option'];
            if ($option)
             {
              if ($option=='update_password')
               {
                include('update_password.php');
              }
              elseif($option=='update_profile')
              {
                include('update_profile.php');

              }
              elseif ($option=='Notification')
               {
                include('Notification.php');
              }
            }
            else {
              header('Location: Notification.php');
            }

            }

              echo "<br>";
              if (isset($_GET['MSG'])) {
              echo $_GET['MSG'];
            }

           ?>
        </div>

      </div>
    </div>


    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" ></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" ></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" ></script>
  </body>
</html>

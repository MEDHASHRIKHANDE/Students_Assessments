<?php

  echo "<h1 style=margin-top:20px;>welcome users</h1><br><h4>This is our online notice board website</h4>";
 ?>

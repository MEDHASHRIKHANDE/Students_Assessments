<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

  </head>
  <body>
      <nav class="container-fluid navbar navbar-expand navbar-dark bg-dark sticky-top">

        <div class="container">
          <ul class="nav navbar-nav">
            <li class="nav-item">
              <a class="nav-link" href="onlinenotice.php">Online notice board</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="onlinenotice.php?option=about"><i class="fa fa-user" aria-hidden="true"></i> About</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="onlinenotice.php?option=contact"><i class="fa fa-phone" aria-hidden="true"></i> Contact</a>
            </li>
          </ul>

          <ul class="nav navbar-nav navbar-right">
            <li class="nav-item">
              <a  class="nav-link" href="onlinenotice.php?option=signup"><i class="fa fa-user" aria-hidden="true"></i> Sign Up</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="onlinenotice.php?option=login"><i class="fa fa-sign-in" aria-hidden="true"></i> Login</a>
            </li>
          </ul>
        </div>
      </nav>

      <div class="container-fluid" >

        <div class="carousel slide" data-ride="carousel"  id="carousel-example">
          <ol class="carousel-indicators">
            <li data-target="#carousel-example" data-slide-to="0" class="active"></li>
            <li data-target="#carousel-example" data-slide-to="1"></li>
          </ol>
          <div class="carousel-inner">
             <div class="carousel-item active">
              <img class="w-100" src="img/slider2.jpg" alt="">
            </div>
            <div class="carousel-item">
              <img class="w-100" src="img/slider3.png" alt="">
            </div>
          </div>
          <a class="carousel-control-prev" href="#carousel-example" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
          </a>
          <a class="carousel-control-next" href="#carousel-example" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
          </a>
        </div>
      </div>


      <div class="container-fluid">
        <div class="container">
          <div class="row">
            <div class="col-lg-8">

              <?php
              if (isset($_GET['msg'])) {
                echo $_GET['msg'];
              }

              if (isset($_GET['option'])) {


              $opt=$_GET['option'];
              if ($opt)
               {
                if ($opt=="about")
                {
                  include('about.php');
                }
                else if($opt=="contact")
                {
                  include('contact.php');
                }
                else if($opt=="signup")
                {
                  include('signup.php');
                }
                elseif ($opt=="login")
                {
                  include('login.php');
                }

              }
              } else {
                echo "<h3 style='padding:30px';>welcome to our online notice board website<br><br> Welcome new users.</h3>";
              }

               ?>
            </div>
            <div class="col-lg-4">

            </div>
          </div>
        </div>
      </div>

      <div class="container-fluid bg-dark mt-3 p-3">
        <div class="container">
          <div class="row">
            <div class="col-lg-12 text-center text-light">
              Copyright (c) 2019  All Rights Reserved by Jitendra Bhor
            </div>
          </div>
        </div>
      </div>

      <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" ></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" ></script>
      <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" ></script>
     </body>
</html>

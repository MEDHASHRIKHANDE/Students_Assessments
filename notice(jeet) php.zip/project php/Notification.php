
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  </head>
  <body>
    <?php

    $conn=mysqli_connect('localhost','root','','noticeboard');
    if ($conn) {
      $user=$_SESSION['name'];
      $sql="select * from notice";
      $result=mysqli_query($conn,$sql);
      if ($result) {
        $record=mysqli_fetch_assoc($result);
        $SrNo=$record['id'];
        $user=$record['user'];
        $Subject=$record['subject'];
        $Details=$record['description'];
        $Date=$record['date'];
      } else {
        // code...
      }

    } else {
      // code...
    }
     ?>
    <div class="row mt-3">
      <div class="col-lg-12">
        <h1>All Notification</h1>
        <table class="table table-bordered">
	         <Tr>
		           <th value="<?php echo $SrNo; ?>">SrNo</th>
               <th>user</th>
		           <th>Subject</th>
		           <th>Details</th>
		           <th>Date</th>
		       </Tr>

      </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" ></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" ></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" ></script>
  </body>
</html>

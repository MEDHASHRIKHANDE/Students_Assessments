 <!DOCTYPE html>
 <html lang="en" dir="ltr">
   <head>
     <meta charset="utf-8">
     <title></title>
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
     <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
   </head>
   <body>
     <?php
     if (isset($_GET['mseg'])) {
       echo $_GET['mseg'];
     }

     $conn = mysqli_connect('localhost','root','','noticeboard');
    $user = $_SESSION['name'];
    $sql = "select * from signup where username='$user'";
    $result =mysqli_query($conn,$sql);

     if ($result == true)
     {
       $record=mysqli_fetch_assoc($result);

       $username=$record['username'];
        $email=$record['email'];
        $mobile=$record['mobile'];

     }
     else
      {
       // code...
     }
      ?>
      <form action="update_profilehandler.php" method="post">
     <div class="row">
       <div class="col-lg-12 text-center">
         <br>
          <h2>Update Your Profile</h2>
       </div>
     </div>
     <br>
     <div class="row">

       <div class="col-lg-3">
         <h6>Enter your username:-</h6>
       </div>
       <div class="col-lg-7">
         <input  class="form-control"type="text" name="username" value="<?php echo $username; ?>">
       </div>
     </div>
     <br>
     <div class="row">
       <div class="col-lg-3">
         <h6>Enter your Email:-</h6>
       </div>
       <div class="col-lg-7">
         <input  class="form-control"type="email" name="email" value="<?php echo $email; ?>" readonly>
       </div>
     </div>

<br>
     <div class="row">
       <div class="col-lg-3">
         <h6>Enter your Mobile:-</h6>
       </div>
       <div class="col-lg-7">
         <input  class="form-control"type="tel" name="mobile" value="<?php echo $mobile; ?>">
       </div>
     </div>
     <br>

     <div class="row">
       <div class="col-lg-12 text-center">
         <input class="btn btn-primary" type="submit" name="update" value="UPDATE">
         <input class="btn btn-primary" type="reset" name="reset" value="RESET">
       </div>

     </div>

   </form>
     <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" ></script>
     <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" ></script>
     <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" ></script>
   </body>
 </html>

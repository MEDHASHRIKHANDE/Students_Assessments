<?php
$conn=mysqli_connect('localhost','root','','noticeboard');
if ($conn) {
  $sql="select * from notice";
  $result=mysqli_query($conn,$sql);
  if ($result) {
    $record=mysqli_fetch_assoc($result);
  } else {
    // code...
  }

} else {
  // code...
}



 ?>

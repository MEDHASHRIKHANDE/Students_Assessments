<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  </head>
  <body>
    <div class="row">
      <form class="col-lg-12 mt-3 p-3" action="login_handler.php" method="post">
        <h2>Login</h2><br>
        <div class="row">
          <div class="col-lg-5">
            <h4>Enter Your Username:-</h4>
          </div>
          <div class="col-lg-7">
            <input class="form-control" type="text" name="username" value="">
          </div>
        </div>
        <br>
        <div class="row">
          <div class="col-lg-5">
            <h4>Enter Your Password:-</h4>
          </div>
          <div class="col-lg-7">
            <input class="form-control" type="password" name="password" value="">
          </div>
        </div>
        <br>
        <div class="row">
          <div class="col-lg-4">

          </div>
          <div class="col-lg-4 text-center">
          <input class="btn btn-success" type="submit" name="login" value=" Login ">
          </div>
          <div class="col-lg-4">

          </div>
        </div>
      </form>
    </div>

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" ></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" ></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" ></script>
  </body>
</html>

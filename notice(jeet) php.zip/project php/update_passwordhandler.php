<?php
if(isset($_POST['update'])){
  $conn =mysqli_connect('localhost','root','','noticeboard');
  session_start();
  $user = $_SESSION['name'];
    $new = $_POST['new'];
    $cnew = $_POST['new_pass'];
  if ($new === $cnew) {

    $sql = "update signup set password='$new' where username='$user'";
    $result = mysqli_query($conn,$sql);
    if ($result) {

      header('Location: dashboard.php?MSG=password updated');
    } else {
      echo "error";
    }

  } else {
    // code...
  }

}else{
  echo "POST IT FIRST";
}


 ?>


 <!DOCTYPE html>
 <html lang="en" dir="ltr">
   <head>
     <meta charset="utf-8">
     <title></title>
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
     <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
   </head>
   <body>
     <div class="row">
      <div class="col-lg-12 text-center p-3">
        <div class="card p-3 bg-secondary">
          <h2>Contact us</h2>
          <div class="card body p-3 bg-light">
            <h3>Name: Sanjeev Kumar
              <br>Mobile: 9015501897
              <br>Email:phptpoint@gmail.com
              <br>Website: Phptpoint
            </h3>
          </div>
        </div>
       </div>

     </div>

     <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" ></script>
     <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" ></script>
     <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" ></script>
   </body>
 </html>

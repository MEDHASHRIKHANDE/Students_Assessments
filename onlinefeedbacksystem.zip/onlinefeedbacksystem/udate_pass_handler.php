<?php
$con=mysqli_connect('localhost','root','','feedback_system');
if ($con) {
  if (isset($_POST['update1'])) {
    $up1=$_POST['upadateuser'];
    $up2=$_POST['upadatepass'];
    $sql="update user set pass='$up2' where pass='$up1'";
    $res=mysqli_query($con,$sql);
    if ($res)
    {
      header('Location:update.php?msg=update successfully');
    }
  }
}


else {
  echo "not update";
}
 ?>

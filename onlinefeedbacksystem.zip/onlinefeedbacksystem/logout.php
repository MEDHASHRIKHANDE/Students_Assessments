<?php
session_start();
session_destroy();
if (isset($_SESSION['name'])) {
  header('Location:login.php?msg= Thank YOU !!!');
}

 ?>

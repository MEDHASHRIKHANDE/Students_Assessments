<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!--iconlink--> <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"><!--close iconlink-->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" >
    <link rel="icon" type="image/ico" href="6.jpg"/>
    <title>user profile </title>
  </head>
  <body>

    <div class="row">
    		<div class="col-sm-2"></div>
    		<div class="col-sm-8">

    <form  action="admin_handler.php" method="post">
    	<div class="row" style="margin-top:80px;">
    		<div class="col-sm-4"></div>
    		<div class="col-sm-4"><h2>Admin LogIn</h2></div>
    	</div><br>

    	<div class="row" style="margin-top:10px">
    		<div class="col-sm-3">Enter Your Email</div>
    		<div class="col-sm-5">
    		<input type="email" name="u1" class="form-control"/></div>
    	</div>

    	<div class="row" style="margin-top:10px">
    		<div class="col-sm-3">Enter Your Password</div>
    		<div class="col-sm-5">
    		<input type="password" name="p1" class="form-control"/></div>
    	</div><br>
    	<div class="row" style="margin-top:10px">
    		<div class="col-sm-4"></div>
    		<div class="col-sm-8">
    		<input style="width:10em;"type="submit" value="Login" name="save" class="btn btn-info"/>

    		</div>
    	</div>
    </form>
    </div>
  </div>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" ></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" ></script>
  </body>
</html>

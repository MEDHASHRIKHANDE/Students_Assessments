
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
      <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
      <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <meta charset="utf-8">
    <title>Online Feedback System</title>
    <style media="screen">
      *{
        margin: 0;
        padding: 0;
        box-sizing: border-box;
      }
    </style>
  </head>
  <body>
    <div class="" style="margin-top: 10px;">
      <?php
      session_start();
       ?>
      <nav class="navbar navbar-dark bg-info">
        <a class="nav-link" style="font-size: 25px;">Hello <span class="text-danger"><?php echo $_SESSION['name']; ?></span></a>
        <ul class="navbar-nav ml-auto">
          <li class="nav-item"><a href="#" class="nav-link text-light"><span class="fa fa-sign-out"></span>Log Out</a></li>
        </ul>
      </nav>
      <div class="row container-fluid" style="margin-top: 30px">
        <div class="left col-lg-3">
          <div class="bg-info" style="height:50px;padding:10px">
            <h4 class="text-light">Dashboard</h4>
          </div><br>
          <center><img src="image.jpg" alt="" style="width:10em; height:10em;border-radius:15vh;"><br><br></center>
            <div class="" style="margin-left: 50px; margin-top: 30px;font-size: 20px;">
              <a href="update.php" class="text-info"><span class="fa fa-user"></span>  Update Password</a><br><br>
              <a href="update_profile.php" class="text-info"><span class="fa fa-snowflake-o"></span>  Update Profile</a><br><br>
              <a href="feedback.php" class="text-info"><span class="fa fa-thumbs-down"></span>  Feedback</a>
            </div>
        </div>
        <div class="right col-lg-9">
          <center><h4><u><a href="#" class="text-dark">Student's Feedback Form</a></u></h4></center><br>
          <br>
          <h3>Please give your answer about the following question by circling the given grade on the scale</h3><br>
          <a href="#" class="btn btn-success">Strongly Agree 5</a>
          <a href="#" class="btn btn-danger">Agree 4</a>
          <a href="#" class="btn btn-primary">Natural 3</a>
          <a href="#" class="btn btn-secondary">Disagree 2</a>
          <a href="#" class="btn btn-danger">Strongly Disagree 1</a>
          <br><br><br>
          <form class="" action="feedback_handler.php" method="post">
          <div class="row">
            <label class="col-lg-3">Select Faculty</label>
            <select class="form-control col-lg-9" name="faculty">
              <option value="Course Material">Course Material</option>
              <option value="Class Teaching">Class Teaching</option>
              <option value="Class Assessment">Class Assessment</option>
            </select>
          </div><br><br>
          <h1>1 - Course Material</h1>

            <div class="form-group row">
              <h5 class="col-lg-9">1 : Teacher provided the course outline having weekly content plan with list of required text book.</h5>
              <div class="col-lg-3">
                <input type="radio" class="col-lg-1" name="1" value="5">5
                <input type="radio" class="col-lg-1" name="1" value="4">4
                <input type="radio" class="col-lg-1" name="1" value="3">3
                <input type="radio" class="col-lg-1" name="1" value="2">2
                <input type="radio" class="col-lg-1" name="1" value="1">1
              </div>
            </div>
            <div class="form-group row">
              <h5 class="col-lg-9">2 : course objectives,learning outcomes and grading criteria are clear to me.</h5>
              <div class="col-lg-3">
                <input type="radio" class="col-lg-1" name="2" value="5">5
                <input type="radio" class="col-lg-1" name="2" value="4">4
                <input type="radio" class="col-lg-1" name="2" value="3">3
                <input type="radio" class="col-lg-1" name="2" value="2">2
                <input type="radio" class="col-lg-1" name="2" value="1">1
              </div>
            </div>
            <div class="form-group row">
              <h5 class="col-lg-9">3 : course integrates thoretical course concepts with the real wolrd examples.</h5>
              <div class="col-lg-3">
                <input type="radio" class="col-lg-1" name="3" value="5">5
                <input type="radio" class="col-lg-1" name="3" value="4">4
                <input type="radio" class="col-lg-1" name="3" value="3">3
                <input type="radio" class="col-lg-1" name="3" value="2">2
                <input type="radio" class="col-lg-1" name="3" value="1">1
              </div>
            </div>
            <h1>2 - Class Teaching</h1>
            <div class="form-group row">
              <h5 class="col-lg-9">4 : Teacher is punctual, arrives on time and leaves on time.</h5>
              <div class="col-lg-3">
                <input type="radio" class="col-lg-1" name="4" value="5">5
                <input type="radio" class="col-lg-1" name="4" value="4">4
                <input type="radio" class="col-lg-1" name="4" value="3">3
                <input type="radio" class="col-lg-1" name="4" value="2">2
                <input type="radio" class="col-lg-1" name="4" value="1">1
              </div>
            </div>
            <div class="form-group row">
              <h5 class="col-lg-9">5 : Teacher is good at stimulating the interest in the course content:</h5>
              <div class="col-lg-3">
                <input type="radio" class="col-lg-1" name="5" value="5">5
                <input type="radio" class="col-lg-1" name="5" value="4">4
                <input type="radio" class="col-lg-1" name="5" value="3">3
                <input type="radio" class="col-lg-1" name="5" value="2">2
                <input type="radio" class="col-lg-1" name="5" value="1">1
              </div>
            </div>
            <div class="form-group row">
              <h5 class="col-lg-9">6 : Teacher is good at explaining the subject matter:</h5>
              <div class="col-lg-3">
                <input type="radio" class="col-lg-1" name="6" value="5">5
                <input type="radio" class="col-lg-1" name="6" value="4">4
                <input type="radio" class="col-lg-1" name="6" value="3">3
                <input type="radio" class="col-lg-1" name="6" value="2">2
                <input type="radio" class="col-lg-1" name="6" value="1">1
              </div>
            </div>
            <div class="form-group row">
              <h5 class="col-lg-9">7 : Teacher's presenataiton was clear,loud ad easy to understand:</h5>
              <div class="col-lg-3">
                <input type="radio" class="col-lg-1" name="7" value="5">5
                <input type="radio" class="col-lg-1" name="7" value="4">4
                <input type="radio" class="col-lg-1" name="7" value="3">3
                <input type="radio" class="col-lg-1" name="7" value="2">2
                <input type="radio" class="col-lg-1" name="7" value="1">1
              </div>
            </div>
            <div class="form-group row">
              <h5 class="col-lg-9">8 : Teacher is good at using innovative teaching methods/ways:</h5>
              <div class="col-lg-3">
                <input type="radio" class="col-lg-1" name="8" value="5">5
                <input type="radio" class="col-lg-1" name="8" value="4">4
                <input type="radio" class="col-lg-1" name="8" value="3">3
                <input type="radio" class="col-lg-1" name="8" value="2">2
                <input type="radio" class="col-lg-1" name="8" value="1">1
              </div>
            </div>
            <div class="form-group row">
              <h5 class="col-lg-9">9 : Teacher is available and helpful during counseling hours:</h5>
              <div class="col-lg-3">
                <input type="radio" class="col-lg-1" name="9" value="5">5
                <input type="radio" class="col-lg-1" name="9" value="4">4
                <input type="radio" class="col-lg-1" name="9" value="3">3
                <input type="radio" class="col-lg-1" name="9" value="2">2
                <input type="radio" class="col-lg-1" name="9" value="1">1
              </div>
            </div>
            <div class="form-group row">
              <h5 class="col-lg-9">10 : Teacher has completed the whole course as per course outline:</h5>
              <div class="col-lg-3">
                <input type="radio" class="col-lg-1" name="10" value="5">5
                <input type="radio" class="col-lg-1" name="10" value="4">4
                <input type="radio" class="col-lg-1" name="10" value="3">3
                <input type="radio" class="col-lg-1" name="10" value="2">2
                <input type="radio" class="col-lg-1" name="10" value="1">1
              </div>
            </div><br><br>
            <h1>3 - Class Assessment</h1>
            <div class="form-group row">
              <h5 class="col-lg-9">11 : Teacher was always fair and impartial:</h5>
              <div class="col-lg-3">
                <input type="radio" class="col-lg-1" name="11" value="5">5
                <input type="radio" class="col-lg-1" name="11" value="4">4
                <input type="radio" class="col-lg-1" name="11" value="3">3
                <input type="radio" class="col-lg-1" name="11" value="2">2
                <input type="radio" class="col-lg-1" name="11" value="1">1
              </div>
            </div>
            <div class="form-group row">
              <h5 class="col-lg-9">12 : Assessment conducted are closely connected to maximize learning objectives:</h5>
              <div class="col-lg-3">
                <input type="radio" class="col-lg-1" name="12" value="5">5
                <input type="radio" class="col-lg-1" name="12" value="4">4
                <input type="radio" class="col-lg-1" name="12" value="3">3
                <input type="radio" class="col-lg-1" name="12" value="2">2
                <input type="radio" class="col-lg-1" name="12" value="1">1
              </div>
            </div>
              <h5>13 : What I liked about the course:</h5>
              <textarea name="liked"  class="form-control col-lg-8"rows="8" cols="80"></textarea>
              <h5>14 : What I disliked about the course:</h5>
              <textarea name="disliked"  class="form-control col-lg-8"rows="8" cols="80"></textarea>
              <br><br>
              <input type="submit" class="btn btn-info btn-lg" name="submit" value="Submit">
          </form>
        </div>
      </div>
    </div><br><br><br>
    <div class="navbar-fixed-bottom nav navbar-inverse bg-info text-light" style="padding:15px;height:40px;">
    		<span style="margin-left:35em;">Developed By DigitalAcademy</span>
    	</div>
  </body>
</html>

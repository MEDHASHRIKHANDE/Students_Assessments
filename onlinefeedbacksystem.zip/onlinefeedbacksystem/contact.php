<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"><!--close iconlink-->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" >
    <link rel="icon" type="image/ico" href="6.jpg"/>
    <title>user profile </title>
  </head>
  <body>
    <div class="container-fulid bg-info">
  <nav class="navbar navbar-expand-lg navbar-light bg-info navbar-fixed-top" role="navigation">
  <a class="navbar-brand col-lg-2 text-light" href="#">Online Feedback System</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse " id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto col-lg-4">



    </ul>
        <ul class="nav navbar-nav">
          <li class="nav-item">
            <a class="nav-link fa fa-home text-light" href="home.php">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link fa fa-info-circle text-light" href="about.php"> About</a>
          </li>
      <li class="nav-item ">
        <a class="nav-link fa fa-sign-in text-light" href="registration.php">Registration</a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link fa fa-sign-in text-light dropdown-toggle" data-toggle="dropdown" >Login
          <span class="caret"></span></a>
       <ul class="dropdown-menu">

         <li><a href="login.php">Student</a></li>
     <li><a href="#">Faculty</a></li>
         <li><a href="#">Admin</a></li>
       </ul>
      </li>
      <li class="nav-item">
        <a class="nav-link fa fa-phone text-light" href="contact.php"> Contact</a>
      </li>
    </ul>
  </div>
</nav>
</div><br><br>
<div class="container">
  <div class="row">
    <div class="col-lg-8">
                <h3>Contact us</h3>
                <form class="" action="contact_handler.php" method="post">
				    <div class="form-group">
                  <label>Name:</label>
                  <input type="text" class="form-control" name="name" required>
                    </div>
                    <div class="form-group">
                      <label>Mobile Number:</label>
                      <input type="tel" class="form-control" name="mobile" required>
                    </div>
                    <div class="form-group">
                      <label>Email Address:</label>
                      <input type="email" class="form-control" name="email" required>
                    </div>
                    <div class="form-group">
                      <label>Message:</label>
                      <textarea rows="8" name="message" cols="80" class="form-control"required></textarea>
                    </div>
                    <div class="form-group">
                    <button type="submit" name="save" class="btn btn-primary">Send Message</button>
                    </div>
                </form></div>
			<div class="col-lg-4" style="margin-top:30px">
                <h3>Contact Details</h3>
                <p>E-20 Sector 63<br>Noida, India 90210<br></p>
                <p><i class="fa fa-phone"></i>P: (123) 456-7890</p>
                <p><i class="fa fa-envelope-o"></i>E</abbr>:<a href="#">name@example.com</a></p>
                <p><i class="fa fa-clock-o"></i>H: Monday - Sunday: 9:00 AM to 9:00 PM</p>
                <ul class="list-group list-group-horizontal ">
                    <li class="list-group-item">
                        <a href="#"><i class="fa fa-facebook-square fa-3x"></i></a>
                    </li>
                    <li class="list-group-item">
                        <a href="#"><i class="fa fa-linkedin-square fa-3x"></i></a>
                    </li>
                    <li class="list-group-item">
                        <a href="#"><i class="fa fa-twitter-square fa-3x"></i></a>
                    </li>
                    <li class="list-group-item">
                        <a href="#"><i class="fa fa-google-plus-square fa-3x"></i></a>
                    </li>
                </ul>
              </div>
            </div>
        </div>
      </div>
<br><br>
<div class="navbar-fixed-bottom nav bg-info text-light" style="padding:15px;height:40px;">
   <span style="margin-left:35em;">Developed By DigitalAcademy</span>
 </div>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" ></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" ></script>
  </body>
</html>

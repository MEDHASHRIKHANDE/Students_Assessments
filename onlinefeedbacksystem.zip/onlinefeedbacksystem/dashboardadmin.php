
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"><!--close iconlink-->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" >
    <link rel="icon" type="image/ico" href="6.jpg"/>
    <title>dashboard</title>
  </head>
  <body>
    <div class="container-fulid bg-info">

        <?php
        session_start();
         ?>
        <nav class="navbar navbar-dark bg-success">
          <h1 class="nav-link" style="font-size: 25px;">Faculty Feedback System <span class="text-danger"><?php echo $_SESSION['name']; ?></span><span class="text-success"></span></h1>
          <ul class="navbar-nav ml-auto">
            <li class="nav-item"><a href="#" class="nav-link text-info"><span class="fa fa-user"></span></a>
            </li>
          </ul>
        </nav></div>
        <div class="container-fluid">
          <div class="row" style="margin-top:20px;">
            <div class="col-4 ">
              <h3 class="bg-success text-light py-3 border"><i style="margin-left:2em;font-size:1.5em;text-decoration:none;" class="fa fa-dashboard fa-fw"></i> Dashboard </h3>
              <div class="bg-success border py-2"><a style="margin-left:4em;font-size:1.5em;text-decoration:none;" href="dashboardadmin.php" class="fa fa-user text-light"> Faculty</a></div>
              <div class="bg-success border py-2"><a style="margin-left:4em;font-size:1.5em;text-decoration:none;" href="addfaculty.php" class="fa fa-user text-light"> Add Faculty</a></div>
              <div class="bg-success border py-2"><a style="margin-left:4em;font-size:1.5em;text-decoration:none;"href="update_profile.php"  class="fa fa-eye text-light"> Manage Faculty</a></div>
              <div class="bg-success border py-2"><a style="margin-left:4em;font-size:1.5em;text-decoration:none;"href="regisrtation.php" class="fa fa-user text-light"> Student</a></div>
              <div class="bg-success border py-2"><a style="margin-left:4em;font-size:1.5em;text-decoration:none;" href="feedback.php" class="fa fa-user fa-book text-light"> Feedback</a></div>
              <div class="bg-success border py-2"><a style="margin-left:4em;font-size:1.5em;text-decoration:none;"href="contact.php"  class="fa fa-eye text-light"> Contact Us</a></div>
            </div>

          <div class="col-8">
    <h1>Add Faculty</h1>
	<form class="" action="dashboard_hanlder.php" method="post">
	<div class="form-group">
        	<label>Name:</label>
            	<input type="text" name="name" class="form-control" required>
        </div>
	<div class="form-group">
        	<label>Designation:</label>
            	<input type="text" name="Designation" class="form-control" required>
        </div>
	<div class="form-group">
        	<label>Email :</label>
            	<input type="email" name="email" class="form-control" required>
        </div>
	<div class="form-group">
        	<label>Password :</label>
            	<input type="password" name="pass" class="form-control" required>
        </div>
	<div class="form-group">
        	<label>Programme:</label>
  <input type="text"  name="prg" class="form-control" required>
</div>
	<div class="form-group">
        	<label>Semester</label>
  <select name="sem" class="form-control" required>

					<option>First</option>
					<option>Second</option>
					<option>Third</option>
					<option>Fourth</option>
					<option>Fifth</option>
					<option>Sixth</option>
					<option>Seventh</option>
					<option>Eighth</option>
					</select>
    </div>

	<div class="form-group">
        	<label>Mobile Number:</label>
            	<input type="tel" class="form-control" name="mob"  required>
        </div>

	<div class="form-group">
         <input type="submit" class="btn btn-success" name="save" value="Add New Faculty">
  	</div>
	</form>
</div>
</div>
</div>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" ></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" ></script>
</body>
</html>

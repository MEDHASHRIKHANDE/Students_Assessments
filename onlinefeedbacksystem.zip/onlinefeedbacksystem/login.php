<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"><!--close iconlink-->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" >
    <link rel="icon" type="image/ico" href="6.jpg"/>
    <title>user profile </title>
  </head>
  <body>
    <div class="container-fulid bg-info">


  <nav class="navbar navbar-expand-lg navbar-light bg-info navbar-fixed-top" role="navigation">
  <a class="navbar-brand col-lg-2 text-light" href="#">Online Feedback System</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse " id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto col-lg-4">



    </ul>
    <form class="form-inline ">
        <ul class="nav navbar-nav">
          <li class="nav-item">
            <a class="nav-link fa fa-home text-light" href="home.php">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link fa fa-info-circle text-light" href="about.php"> About</a>
          </li>
      <li class="nav-item ">
        <a class="nav-link fa fa-sign-in text-light" href="registration.php">Registration</a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link fa fa-sign-in text-light dropdown-toggle" data-toggle="dropdown"> Login
          <span class="caret"></span></a>
       <ul class="dropdown-menu">

         <li><a href="login.php">Student</a></li>
     <li><a href="faculty.php">Faculty</a></li>
         <li><a href="admin.php">Admin</a></li>
       </ul>
      </li>
      <li class="nav-item">
        <a class="nav-link fa fa-phone text-light" href="#"> Contact</a>
      </li>
    </ul>
    </form>
  </div>
</nav>
    </div>
  </div><br><br>
    <div class="row">
    		<div class="col-sm-2"></div>
    		<div class="col-sm-8">
          <?php
          if (isset($_GET['msg'])) {
            echo $_GET['msg'];
          }


           ?>
    <form  action="login_handler.php" method="post">
    	<div class="row">
    		<div class="col-sm-4"></div>
    		<div class="col-sm-4"><h2>Login Form</h2></div>
    	</div><br><br>

    	<div class="row" style="margin-top:10px">
    		<div class="col-sm-3">Enter Your Email</div>
    		<div class="col-sm-5">
    		<input type="email" name="u1" class="form-control"/></div>
    	</div>

    	<div class="row" style="margin-top:10px">
    		<div class="col-sm-3">Enter Your Password</div>
    		<div class="col-sm-5">
    		<input type="password" name="p1" class="form-control"/></div>
    	</div><br>
    	<div class="row" style="margin-top:10px">
    		<div class="col-sm-4"></div>
    		<div class="col-sm-8">
    		<input style="width:10em;"type="submit" value="Login" name="save" class="btn btn-info"/>

    		</div>
    	</div>
    </form>
    </div>
  </div><br><br><br><br>


<div class="navbar-fixed-bottom nav navbar-inverse bg-info text-light" style="padding:15px;height:40px;">
   <span style="margin-left:35em;">Developed By DigitalAcademy</span>
 </div>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" ></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" ></script>
  </body>
</html>

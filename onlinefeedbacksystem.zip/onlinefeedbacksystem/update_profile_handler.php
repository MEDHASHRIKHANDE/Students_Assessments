<?php
$con=mysqli_connect("localhost","root","","feedback_system");

if ($con) {
  if (isset($_POST['update1'])) {
    $updn1=$_POST['n1'];
    $upde1=$_POST['e1'];
    $updm1=$_POST['m1'];
    $uppro1=$_POST['pro'];
    $upsem1=$_POST['sem'];
    $updh1=$_POST['h1'];
    $updph1=$_POST['ph1'];
    $updd1=$_POST['d1'];


    $sql="update user set name = '$updn1', email= '$upde1', mobile= '$updm1',programme='$uppro1', semester='$upsem1', hobbies= '$updh1', image= '$updph1', dob= '$updd1' where name ='".$updn1."'";
    $res=mysqli_query($con,$sql);
    if ($res)
    {
      header('Location:update_profile.php?msg=Update Successfully');
    }else{
      echo "error";
    }

  }
}else{
  echo "please enter correct information";
}
 ?>

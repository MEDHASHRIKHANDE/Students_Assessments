<?php
$conn = mysqli_connect("localhost","root","","feedback_system");
if (isset($_POST['save'])){
  session_start();
  $name = $_POST['name'];
  $email = $_POST['email'];
  $mob = $_POST['mobile'];
  $msg = $_POST['message'];
  $date = 'SYSDATE()';

  $sql = "insert into contact values(null,'$name','$email','$mob','$msg',$date)";
    //echo $sql;
$result = mysqli_query($conn,$sql);
if($result == True){
  header('Location:home.php?msg=Thanks We will reach to you');
}
}else{

  echo "Come In Right Way";
}

 ?>

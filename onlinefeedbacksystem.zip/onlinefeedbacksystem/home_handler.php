<?php
					@$info=$_GET['info'];
					if($info!="")
					{

						 if($info=="about")
						 {
						 include('about.php');
						 }






						 else if($info=="contact")
						 {
						 include('contact.php');
						 }




						 else if($info=="login")
						 {
						 include('login.php');
						 }

						  else if($info=="faculty_login")
						 {
						 include('faculty_login.php');
						 }


						 else if($info=="registration")
						 {
						 	include('registration.php');
						 }
					}
					else
					{
				?>

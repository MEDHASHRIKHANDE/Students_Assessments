 <!DOCTYPE html>
 <html lang="en" dir="ltr">
   <head>
     <meta charset="utf-8">
     <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"><!--close iconlink-->
     <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" >
     <link rel="icon" type="image/ico" href="6.jpg"/>
     <title>user profile </title>
   </head>
   <body>
     <div class="container-fulid bg-info">


   <nav class="navbar navbar-expand-lg navbar-light bg-info navbar-fixed-top" role="navigation">
   <a class="navbar-brand col-lg-2 text-light" href="#">Online Feedback System</a>
   <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
     <span class="navbar-toggler-icon"></span>
   </button>

   <div class="collapse navbar-collapse " id="navbarSupportedContent">
     <ul class="navbar-nav mr-auto col-lg-4">



     </ul>
         <ul class="nav navbar-nav">
           <li class="nav-item">
             <a class="nav-link fa fa-home text-light" href="home.php">Home</a>
           </li>
           <li class="nav-item">
             <a class="nav-link fa fa-info-circle text-light" href="about.php"> About</a>
           </li>
       <li class="nav-item ">
         <a class="nav-link fa fa-sign-in text-light" href="registration.php">Registration</a>
       </li>
       <li class="nav-item dropdown">
         <a class="nav-link fa fa-sign-in text-light dropdown-toggle" data-toggle="dropdown" >Login
           <span class="caret"></span></a>
        <ul class="dropdown-menu">

          <li><a href="login.php">Student</a></li>
		  <li><a href="#">Faculty</a></li>
          <li><a href="adminlogin.php">Admin</a></li>
        </ul>
       </li>
       <li class="nav-item">
         <a class="nav-link fa fa-phone text-light" href="#"> Contact</a>
       </li>
     </ul>
   </div>
 </nav>
     </div>
     </div>
     <div class="container-fulid">
       <div class="row">
         <div class="col">
     <form class="" action="" method="post">
       <br><br>
       <center> <h1> Sign Up<hr></h1>
         <?php
         if (isset($_GET['msg'])) {
           echo $_GET['msg'];
         }
          ?>
       <table border='1'>
         <th colspan="2" style="height:1em;"></th>
         <tr>
           <th style="padding:.5em;">Enter Your Name</th>
             <th style="padding:.5em;"><input style="width:100%;"type="text" name="n1" value="" required></th>
           </tr>
           <tr>
             <th style="padding:.5em;">Enter Your Email-id</th>
               <th style="padding:.5em;"><input style="width:100%;" type="email" name="e1" value="" required></th>
             </tr>
             <tr>
               <th style="padding:.5em;">Enter Your Password</th>
                 <th style="padding:.5em;"><input style="width:100%;" type="password" name="p1" value="" required></th>
               </tr>
             <tr>
               <th style="padding:.5em;">Enter Your mobile</th>
                 <th style="padding:.5em;"><input style="width:100%;" type="tel" name="m1" value="" required></th>
               </tr>
               <tr>
                 <th style="padding:.5em;">Select Your Programme</th>
                   <th style="padding:.5em;"><select name="pro" style="width:100%;padding:.3em;"required>
					         <option style="padding:.5em;">BSC</option>
					         <option style="padding:.5em;">BA</option>
					         <option style="padding:.5em;">BCOM</option>
					         <option style="padding:.5em;">B.E.</option>
                   <option style="padding:.5em;">MCA</option>
					         </select></th>
                 </tr>
                 <th style="padding:.5em;">Select Your Semester</th>
           <th style="padding:.5em;"><select name="sem" style="width:100%;padding:.3em;"required>
					<option style="padding:.5em;">First</option>
					<option style="padding:.5em;">Second</option>
					<option style="padding:.5em;">Third</option>
					<option style="padding:.5em;">Fourth</option>
					<option style="padding:.5em;">FIFTH</option>
					<option style="padding:.5em;">SIXTH</option>
					<option style="padding:.5em;">SEVENTH</option>
					<option style="padding:.5em;">EIGHTH</option>
					</select></th>
                 </tr>

                 <tr>
                 <th style="padding:.5em;">Select Your Gender</th>
                   <th style="padding:.5em;"><input type="radio" name="g1" value="male" required>&nbsp;Male&nbsp;&nbsp;&nbsp;&nbsp;
                   <input type="radio" name="g1" value="female" required>&nbsp;Female<br></th>
                 </tr>
               <tr>
                 <th style="padding:.5em;">Choose Your Hobbies</th>
                 <th style="padding:.5em;"><input type="checkbox" name="h1" value="reading" > Reading&nbsp;
                 <input type="checkbox" name="h12" value="singing" > Singing&nbsp;
                 <input type="checkbox" name="h13" value="playing" > Playing</th>
                 </tr>

                 <tr>
                   <th style="padding:.5em;">Upload Your Image</th>
                     <th style="padding:.5em;"><input type="file" name="ph1" value="" required></th>
                   </tr>
                   <tr>
                     <th style="padding:.5em;">Enter Your DOB</th>
                       <th style="padding:.5em;"><input type="date" name="d1" value="" style="width:100%;"required></th>
                     </tr>
                     <tr>
                        <th colspan="2" style="padding:.5em;">
                       <input style="width:45%;" type="submit" name="su1" value="Save" class="btn btn-info">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                       &nbsp;&nbsp;&nbsp;&nbsp;<input style="width:45%;" type="reset" value="Reset" class="btn btn-info"/></th>

                     </tr>

       </table>
     </center>
     </form>
   </div>
 </div>
</div><br><br>
<div class="navbar-fixed-bottom nav bg-info text-light" style="padding:15px;height:40px;">
		<span style="margin-left:35em;">Developed By DigitalAcademy</span>
	</div>
     <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
     <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" ></script>
     <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" ></script>
   </body>
 </html>
 <?php
 $conn=mysqli_connect('localhost','root','','feedback_system');
 if (isset($_POST['su1']))
 {
   $name1=$_POST['n1'];
   $email1=$_POST['e1'];
   $password1=$_POST['p1'];
   $mobile1=$_POST['m1'];
   $programm1=$_POST['pro'];
   $sem1=$_POST['sem'];
   $gender1=$_POST['g1'];
   $hobbies1=$_POST['h1']." ".$_POST['h12']." ".$_POST['h13'];
   $photo1=$_POST['ph1'];
   $dob1=$_POST['d1'];
   $sql="insert into user values(null,'".$name1."','".$email1."','".$password1."','".$mobile1."', '".$programm1."', '".$sem1."','".$gender1."','".$hobbies1."','".$photo1."','".$dob1."',null)";
   $res=mysqli_query($conn,$sql);
   if ($res)
   {
     header('Location:registration.php?msg=created account');
   }
   else {
       header('Location:registration.php?msg=try again create account');
   }
 }


  ?>

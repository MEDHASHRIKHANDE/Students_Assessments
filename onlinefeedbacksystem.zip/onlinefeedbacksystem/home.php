<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"><!--close iconlink-->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" >
    <link rel="icon" type="image/ico" href="6.jpg"/>
    <title>user profile </title>
  </head>
  <body>
    <div class="container-fulid bg-info">


  <nav class="navbar navbar-expand-lg navbar-light bg-info navbar-fixed-top" role="navigation">
  <a class="navbar-brand col-lg-2 text-light" href="#">Online Feedback System</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse " id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto col-lg-4">



    </ul>
        <ul class="nav navbar-nav">
          <li class="nav-item">
            <a class="nav-link fa fa-home text-light" href="home.php">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link fa fa-info-circle text-light" href="about.php"> About</a>
          </li>
      <li class="nav-item ">
        <a class="nav-link fa fa-sign-in text-light" href="registration.php">&nbsp;Registration</a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link fa fa-sign-in text-light dropdown-toggle" data-toggle="dropdown" >Login
          <span class="caret"></span></a>
       <ul class="dropdown-menu">

         <li><a href="login.php">Student</a></li>
     <li><a href="#">Faculty</a></li>
         <li><a href="adminlogin.php">Admin</a></li>
       </ul>
      </li>
      <li class="nav-item">
        <a class="nav-link fa fa-phone text-light" href="#"> Contact</a>
      </li>
    </ul>
  </div>
</nav>
    </div>
    <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
          <ol class="carousel-indicators">
            <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
          </ol>
          <div class="carousel-inner">
            <div class="carousel-item active">
              <img src="feedback2.jpg" class="d-block w-100" style="height:80vh" alt="...">
            </div>
            <div class="carousel-item">
              <img src="images.jpeg" class="d-block w-100" style="height:80vh" alt="...">
            </div>
            <div class="carousel-item">
              <img src="feedback.jpg" class="d-block w-100" style="height:80vh" alt="...">
            </div>
          </div>
          <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
          </a>
          <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
          </a>
        </div><br><br>
        <div class="container"><?php
        if (isset($_GET['msg'])) {
          echo $_GET['msg'];
        }
         ?><br><br>
          <h2> About Faculty Feedback System</h2>
          <p> Student Feedback System for college students have been developed which aims to rate and analyse the college faculty’s performance.

This type of Student Feedback system reduces, the strenuous work of physically examining the feedback pages of each and every student.

The system also reduces the burden of efforts and burden of keeping and maintaining the records on a manual base, it requires a lot of space and safety to keep up such records.

Also the students feedbacks can be tempered for wrong reasons in case of paper based feedbacks wherein the SFS will always ensure safety of feedbacks privacy.

Another important features of the SFS is that physical presence of neither the admin nor the student is required for the either giving the feedback nor for assessing the feedback.

Also further enhancement can be done and more features can be added for better retrieval of the feedback details.</p>
        </div>
<br><br>
<div class="navbar-fixed-bottom nav bg-info text-light" style="padding:15px;height:40px;">
   <span style="margin-left:35em;">Developed By DigitalAcademy</span>
 </div>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" ></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" ></script>
  </body>
</html>

<?php
$conn = mysqli_connect("localhost","root","","feedback_system");
if (isset($_POST['save'])){
  session_start();
  $user = $_SESSION['name'];
  $faculty = $_POST['name'];
  $second = $_POST['Designation'];
  $third = $_POST['prg'];
  $fourth = $_POST['sem'];
  $fifth = $_POST['email'];
  $sixth = $_POST['pass'];
  $seventh = $_POST['mob'];
  $date = 'SYSDATE()';
  $stat=1;

  $sql = "insert into faculty values(null,'$user','$faculty','$second','$third','$fourth','$fifth','$sixth','$seventh',$date,'$stat')";
    //echo $sql;
$result = mysqli_query($conn,$sql);
if($result == True){

  echo "<h1>Thanks for feed back</h1>";
  echo "<a href='dashboardamin.php'>Go to Dashboard</a>";
}
}else{

  echo "Come In Right Way";
}

 ?>

<?php

$conn=mysqli_connect("localhost","root","","feedback_system");
if (isset($_POST['save'])) {

  $user=$_POST['u1'];
  $pass=$_POST['p1'];
  $sql="select*from user where email ='".$user."' and pass = '".$pass."'";
  $result=mysqli_query($conn,$sql);
  $row=mysqli_num_rows($result);
  if($row){
  $record = mysqli_fetch_assoc($result);
        $db = $record['email'];
        $dd = $record['pass'];
  if ($user === $db && $pass === $dd) {
    session_start();

          $_SESSION['name'] =$record['email'];
          header('Location:dashboard.php');
          }else{
          header('Location:login.php?msg=Invalid username or password');
          }
        }
          else {
          header('Location:registration.php?msg=Pls register with us Thank You');
        }
  }else{
    header('Location:registration.php?msg=ERROR');
  }

    ?>

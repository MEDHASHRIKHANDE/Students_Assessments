<?php
$conn = mysqli_connect("localhost","root","","feedback_system");
if (isset($_POST['submit'])){
  session_start();
  $user = $_SESSION['name'];
  $faculty = $_POST['faculty'];
  $first = $_POST['1'];
  $second = $_POST['2'];
  $third = $_POST['3'];
  $fourth = $_POST['4'];
  $fifth = $_POST['5'];
  $sixth = $_POST['6'];
  $seventh = $_POST['7'];
  $eighth = $_POST['8'];
  $ninth = $_POST['9'];
  $tenth = $_POST['10'];
  $eleventh = $_POST['11'];
  $twelth = $_POST['12'];
  $liked = $_POST['liked'];
  $disliked = $_POST['disliked'];
  $date = 'SYSDATE()';

  $sql = "insert into feedback values(null,'$user','$faculty',$first,$second,$third,$fourth,$fifth,$sixth,$seventh,$eighth,$ninth,$tenth,$eleventh,$twelth,'$liked','$disliked',$date)";
    //echo $sql;
$result = mysqli_query($conn,$sql);
if($result == True){

  echo "<h1>Thanks for feed back</h1>";
  echo "<a href='dashboard.php'>Go to Dashboard</a>";
}
}else{

  echo "Come In Right Way";
}

 ?>

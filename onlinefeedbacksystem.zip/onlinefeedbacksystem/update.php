<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!--iconlink--> <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"><!--close iconlink-->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" >
    <link rel="icon" type="image/ico" href="6.jpg"/>
    <title></title>
  </head>
  <body>
    <div class="container-fulid bg-info">
      <?php
      session_start();
       ?>
      <nav class="navbar navbar-dark bg-info">
        <a class="nav-link" style="font-size: 25px;">Hello <span class="text-danger"><?php echo $_SESSION['name']; ?></span></a>
        <ul class="navbar-nav ml-auto">
          <li class="nav-item"><a href="#" class="nav-link text-light"><span class="fa fa-sign-out"></span>Log Out</a></li>
        </ul>
      </nav></div><br>
<div class="container-fulid ">
      <div class="row">
        <div class="col-4 ">
          <h3 class="bg-info text-center text-light py-3 border">Dashboard </h3><br><br>
          <img src="image.jpg" style="width:10em; height:10em;margin-left:8em;border-radius:15vh;"><br><br>
          <a style="margin-left:4em;font-size:1.5em;text-decoration:none;" href="chengepassword.php" class="fa fa-user text-info"> Update Password</a><br><br>
          <a style="margin-left:4em;font-size:1.5em;text-decoration:none;"href="update_profile.php"  class="fa fa-snowflake-o text-info"> Update Profile</a><br><br>
          <a style="margin-left:4em;font-size:1.5em;text-decoration:none;"href="feedback.php" class="fa fa-thumbs-o-down text-info"> Feedback</a><br><br>
        </div>
      <div class="col-lg-8">

    <?php
    if (isset($_GET['msg'])) {
      echo $_GET['msg'];
    }
     ?>
     <center><h2>Update Password</h2><br><br>
    <form class="" action="udate_pass_handler.php" method="post">
      <label>Enter old password</label>
      <input type="password" name="upadateuser" required><br><br>
      <label>Enter new password</label>
      <input type="password" name="upadatepass" value="" required><br><br>
      <input type="submit" class="btn btn-info"name="update1" value="update"><br><br>
    </form></center>

    </div>
    </div>
  </div>
  <br><br><br>
  <div class="navbar-fixed-bottom nav navbar-inverse bg-info text-light" style="padding:15px;height:40px;">
      <span style="margin-left:35em;">Developed By DigitalAcademy</span>
    </div>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" ></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" ></script>
  </body>
</html>

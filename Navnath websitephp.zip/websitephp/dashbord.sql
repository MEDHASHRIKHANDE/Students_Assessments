-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jul 11, 2019 at 10:13 AM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dashbord`
--

-- --------------------------------------------------------

--
-- Table structure for table `adminsignup`
--

CREATE TABLE `adminsignup` (
  `sid` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `mobile` varchar(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `hobbies` varchar(250) NOT NULL,
  `photo` varchar(250) NOT NULL,
  `dob` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `adminsignup`
--

INSERT INTO `adminsignup` (`sid`, `name`, `email`, `username`, `password`, `mobile`, `gender`, `hobbies`, `photo`, `dob`) VALUES
(1, 'admin', 'admin@gmail.com', 'admin123', 'admin09', '9820133183', 'male', 'painting', 'Screenshot from 2019-06-17 05-15-13.png', '2019-07-08'),
(2, 'a', 'a', '', 'admin123', '91728220022929', 'male', 'awa', 'Screenshot from 2019-07-08 22-38-18.png', '2019-07-10');

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `news_id` int(100) NOT NULL,
  `title` varchar(250) NOT NULL,
  `desc` text NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`news_id`, `title`, `desc`, `date`) VALUES
(1, 'rain', 'ran ran....', '2019-07-06'),
(2, 'not rain', 'go go...', '2018-12-03');

-- --------------------------------------------------------

--
-- Table structure for table `noticesbord`
--

CREATE TABLE `noticesbord` (
  `notices_id` int(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `title` varchar(250) NOT NULL,
  `sub` varchar(250) DEFAULT NULL,
  `descripation` text DEFAULT NULL,
  `date` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `noticesbord`
--

INSERT INTO `noticesbord` (`notices_id`, `username`, `title`, `sub`, `descripation`, `date`) VALUES
(110, 'navnath123', 'aa', 'ss', 'dd', '2019-07-11'),
(111, 'navnath123', 'aa', 'ss', 'dd', '2019-07-11'),
(112, 'hari123', 'title', 'subject', 'desc', '2019-07-11');

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--

CREATE TABLE `signup` (
  `sid` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `mobile` varchar(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `hobbies` varchar(250) NOT NULL,
  `photo` varchar(250) NOT NULL,
  `dob` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `signup`
--

INSERT INTO `signup` (`sid`, `name`, `email`, `username`, `password`, `mobile`, `gender`, `hobbies`, `photo`, `dob`) VALUES
(16, 'navnath', 'navnathkisan97@gmail.com', 'navnath123', '123', '182890220982789', 'male', 'shjsi', 'chef3.jpeg', '2019-07-11');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `adminsignup`
--
ALTER TABLE `adminsignup`
  ADD PRIMARY KEY (`sid`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`news_id`);

--
-- Indexes for table `noticesbord`
--
ALTER TABLE `noticesbord`
  ADD PRIMARY KEY (`notices_id`);

--
-- Indexes for table `signup`
--
ALTER TABLE `signup`
  ADD PRIMARY KEY (`sid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `adminsignup`
--
ALTER TABLE `adminsignup`
  MODIFY `sid` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `news_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `noticesbord`
--
ALTER TABLE `noticesbord`
  MODIFY `notices_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=113;

--
-- AUTO_INCREMENT for table `signup`
--
ALTER TABLE `signup`
  MODIFY `sid` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<?php
  if (isset($_POST['update1'])) {
    $con=mysqli_connect('localhost','root','','dashbord');
    $updu1=$_POST['u1'];
    $updn1=$_POST['n1'];
    $upde1=$_POST['e1'];
    $updm1=$_POST['m1'];
    $updg1=$_POST['g1'];
    $updh1=$_POST['h1'];
    $updph1=$_POST['ph1'];
    $updd1=$_POST['d1'];
    $sql="update signup set name='$updn1',email='$upde1',mobile='$updm1',gender='$updg1',hobbies='$updh1',photo='$updph1',dob='$updd1' where username='$updu1'";

    $res=mysqli_query($con,$sql);
    if ($res)
    {
      ?> <script type="text/javascript">
        alert('Upadate password Successfully!!!')
      </script>
      <?php
      header('location:update.php? msg=update details');
    }


/*$s1=$_SESSION['username'];
  $sql1="select * from signup where username='$s1'";
  $res1=mysqli_query($con,$sql1);
  $row1=mysqli_affected_rows($con);
  while ($row1) {
    echo $row1['email'];
  }
*/
}

 ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <div class="container-fulid bg-dark">
      <?php include 'profilehader.php' ?>
    </div>
    <div class="container-fulid">
      <div class="row">
      <div class="col-lg-4">
        <?php include 'profilenavbar.php' ?>
      </div>
      <div class="col-lg-8">
        <form class="" action="" method="post">
          <h2> Update Info</h2>
            <?php
            if (isset($_GET['msg'])) {
              echo $_GET['msg'];
            }
             ?>

            <div class="form-group row">
              <label  >Usename</label>
              <input type="text" name="u1" value="" required class="form-control" placeholder=" " >
            </div>
            <div class="form-group row">
              <label  >Name</label>
              <input type="text" name="n1" value="" required class="form-control">
            </div>
            <div class="form-group row">
              <label  >Email-id</label>
              <input type="email" name="e1" value="" required class="form-control">
            </div>
            <div class="form-group row">
              <label >mobile</label>
              <input type="tel" name="m1" value="" required class="form-control">
            </div>
            <div class="form-group row">
              <label >Gender</label>
              <input type="radio" name="g1" value="male" required >Male
              <input type="radio" name="g1" value="female" required > Female
              <input type="radio" name="g1" value="other" required > Other
            </div>
            <div class="form-group row">
              <label >hobbies</label>
              <input type="text" name="h1" value="" required class="form-control">
            </div>
            <div class="form-group row">
              <label >photo</label>
              <input type="file" name="ph1" value="" required class="form-control">
            </div>
            <div class="form-group row">
              <label >dob</label>
              <input type="date" name="d1" value="" required class="form-control">
            </div>
            <button type="submit" name="update1" class="btn btn-primary">Upadate</button>
            <a href="profileupdate.php"><button type="button"class="btn btn-link">go back</button></a>
        </form>


  </body>
</html>

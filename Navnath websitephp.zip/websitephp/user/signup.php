<?php
$con=mysqli_connect('localhost','root','','dashbord');
if (isset($_POST['su1']))
{
  $name1/*new variable*/=$_POST['n1']/* inputbox name="n1"*/;
  $email1=$_POST['e1'];
  $username1=$_POST['u1'];
  $password1=$_POST['p1'];
  $mobile1=$_POST['m1'];
  $gender1=$_POST['g1'];
  $hobbies1=$_POST['h1'];
  $photo1=$_POST['ph1'];
  $dob1=$_POST['d1'];
  $sql= "insert into signup values(null,'".$name1."','".$email1."','".$username1."','".$password1."','".$mobile1."','".$gender1."','".$hobbies1."','".$photo1."','".$dob1."')";
  $res=mysqli_query($con,$sql);
  if ($res)
  {
    header('location:signup.php? msg=created account');
  }
  else {
      header('location:signup.php? msg=try again create account');
  }
}


 ?>
 <!DOCTYPE html>
 <html lang="en" dir="ltr">
   <head>
     <meta charset="utf-8">
     <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
     <!--iconlink--> <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"><!--close iconlink-->
     <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" >
     <link rel="icon" type="image/ico" href="6.jpg"/>
     <title>user profile </title>
   </head>
   <body>

     <div class="container">
       <div class="row">
         <div class="col">
     <form class="" action="" method="post">
       <center> <h1> Sign Up</h1></center>
       <?php
         if (isset($_GET['msg'])) {
           ?><font color="red"> <?php echo $_GET['msg'];?></font><?php
         }
          ?>

          <div class="form-group">
              <label>Name</label>
              <input type="text" name="n1" value="" class="form-control">
              </div>
              <div class="form-group">
              <label>Email-id</label>
              <input type="email" name="e1" value="" class="form-control">
              </div>
              <div class="form-group">
              <label>username</label>
              <input type="text" name="u1" value="" class="form-control">
              </div>
              <div class="form-group">
              <label>password</label>
              <input type="password" name="p1" value="" class="form-control">
              </div>
              <div class="form-group">
              <label>Mobile</label>
              <input type="number" name="m1" value="" class="form-control">
              </div>
              <div class="form-check form-check-inline">
              <label>Gender</label>
      <input class="form-check-input" type="radio" name="g1"  value="male">
      <label class="form-check-label" for="inlineRadio1">Male</label>
    </div>
    <div class="form-check form-check-inline">
      <input class="form-check-input" type="radio" name="g1"  value="female">
      <label class="form-check-label" for="inlineRadio2">Female</label>
    </div>
    <div class="form-check form-check-inline">
      <input class="form-check-input" type="radio" name="g1"  value="other" >
      <label class="form-check-label" for="inlineRadio3">Orther</label>
    </div>
              <div class="form-group">
              <label>Hobbies</label>
              <input type="text" name="h1" value="" class="form-control">
              </div>
              <div class="form-group">
              <label>photo</label>
              <input type="file" name="ph1" value="" class="form-control">
              </div>
              <div class="form-group">
              <label>Date</label>
              <input type="date" name="d1" value="" class="form-control">
              </div>
                       <input type="submit" name="su1" value="submit" class="btn btn-primary">
                       <a href="index.php">login</a>

     </form>
   </div>

 </div>
</div>
     <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
     <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" ></script>
     <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" ></script>
   </body>
 </html>

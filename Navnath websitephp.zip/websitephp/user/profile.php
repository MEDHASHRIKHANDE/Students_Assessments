<?php
session_start();

$_SESSION['name']=$record['name'];
$con=mysqli_connect('localhost','root','','testphp');
if (isset($_POST['submit'])) {
  print_r($_FILES['img']);
  $file_name=$_FILES['img']['name'];
  $file_tmp_name=$_FILES['img']['tmp_name'];
  $folder="img/";
  move_uploaded_file($file_tmp_name,$folder.$file_name);
  $sql="update signup set img='".$file_name."' where name='".$_SESSION['name']."'";
  $res=mysqli_query($con,$sql);
} else {

}

 ?>

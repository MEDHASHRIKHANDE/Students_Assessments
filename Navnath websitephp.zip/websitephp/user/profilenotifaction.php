<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!--iconlink--> <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"><!--close iconlink-->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" >
    <link rel="icon" type="image/ico" href="6.jpg"/>
    <title>user profile </title>
  </head>
  <body>
    <div class="container-fulid bg-dark">
      <?php include 'profilehader.php' ?>
    </div>
    <div class="container-fulid">
      <div class="row">
      <div class="col-lg-4">
        <?php include 'profilenavbar.php' ?>
      </div>
        <div class="col-lg-8">
          <?php
          $s1=$_SESSION['name'];
          $con=mysqli_connect('localhost','root','','dashbord');
          $sql="select * from noticesbord  where username='$s1' order by date desc";
          $res=mysqli_query($con,$sql);
          echo "<br><br><h2>All Notification</h2>";
          if ($res-> num_rows >0)
          {
            while($row=$res->fetch_assoc()){
              echo "<div class='card'>";
              echo "<h5 class='card-header'>".$row['title']."</h5>";
              echo "<div class='card-body'>";
              echo "<h5 class='card-title'>".$row['sub']."</h5>";
              echo "<p class='card-text'>".$row['descripation']."</p>";
              echo " <blockquote class='blockquote-footer'>".$row['date']."</blockquote></div></div>";
          }
          }
          ?>
          <?php
          /*
          $con=mysqli_connect('localhost','root','','dashbord');
          if ($con) {
            if (isset($_POST['save1'])) {
              $nu2=$_POST['nu1'];
              $nsub2=$_POST['nsub1'];
              $ndesc2=$_POST['ndesc1'];
              $nd2=$_POST['nd1'];
              $sql= "update noticesbord set sub='$nsub2',descripation='$ndesc2',date='$nd2' where user_id='$nu2'";
              $res=mysqli_query($con,$sql);
              if ($res)
              {
                    header('location:updatenotifaction.php? msg=update details');
                }
              else {
                ?> <script type="text/javascript">
                  alert('Not Update Details Enter Check username')
                </script>
                <?php
              }
            }
          }
          else {
            echo "not update";
          }*/
           ?>
          <!-- <form class="" action="#" method="post">-->
             <?php
             /*if (isset($_GET['msg'])) {
               echo $_GET['msg'];
             }*/
              ?>

             <!--<table>
               <tr>
                 <tr>
                   <th>username</th>
                     <th><input type="text" name="nu1" value="" required></th>
                   </tr>
                 <tr>
                   <th>subject</th>
                     <th><input type="text" name="nsub1" value=""></th>
                   </tr>
                   <tr>
                     <th>desc</th>
                       <th><input type="text" name="ndesc1" value=""></th>
                     </tr>
                     <tr>
                       <th>date</th>
                         <th><input type="date" name="nd1" value=""></th>
                       </tr>
                     <th><input type="submit" name="save1" value="save"></th>

               </tr>
             </table>
           </form>-->
        </div>
      </div>
</div>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" ></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" ></script>
  </body>
</html>

<?php

?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!--iconlink--> <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"><!--close iconlink-->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" >
    <link rel="icon" type="image/ico" href="6.jpg"/>
    <title>website php</title>


  </head>
  <body>
    <div class="container-fulid bg-info">


  <nav class="navbar navbar-expand-lg navbar-light bg-dark ">
  <a class="navbar-brand col-lg-2 text-light" href="#">Online Notice Board</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse " id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto col-lg-4">
      <li class="nav-item">
        <a class="nav-link fa fa-info-circle text-light" href="#"> About</a>
      </li>
      <li class="nav-item">
        <a class="nav-link fa fa-address-book-o text-light" href="#"> Contact</a>
      </li>

    </ul>
    <form class="form-inline ">
        <ul class="navbar-nav ">
      <li class="nav-item ">
        <a class="nav-link fa fa-user text-light" href="signup.php"> Signup</a>
      </li>
      <li class="nav-item">
        <a class="nav-link fa fa-sign-in text-light" href="#login"> Login</a>
      </li>
    </ul>
    </form>
  </div>
</nav>
    </div>
    <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
      <ol class="carousel-indicators">
        <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
        <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
        <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
      </ol>
      <div class="carousel-inner">
        <div class="carousel-item active">
          <img src="1.jpg" class="d-block w-100" style="height:70vh" alt="...">
        </div>
        <div class="carousel-item">
          <img src="2.jpg" class="d-block w-100" style="height:70vh" alt="...">
        </div>
        <div class="carousel-item">
          <img src="3.jpg" class="d-block w-100" style="height:70vh" alt="...">
        </div>
      </div>
      <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
      </a>
      <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
      </a>
    </div>
    <br><br>
    <div class="container">
      <div class="float-left" id="login"> <?php include 'login.php';?> </div>
      <div class="float-right"> <?php include 'news.php';?> </div>
    </div>
    <div class="" style="margin-top:40vh;">
      <?php include 'footer.php' ?>
    </div>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" ></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" ></script>
  </body>
</html>

<?php
$con=mysqli_connect('localhost','root','','dashbord');
if (isset($_POST['loginsubmitbutton'])) {
  $lusername1=$_POST['lu1'];
  $lpassword1= $_POST['lp1'];

    $res=mysqli_query($con,"select * from signup where username ='$lusername1'");
    if ($res) {
      $record=mysqli_fetch_assoc($res);
      $lusername2=$record['username'];//coulman name-username
      $lpassword2=$record['password'];
      if ($lusername2===$lusername1 && $lpassword2===$lpassword1) {
        if ($lusername1){
          session_start();
            $_SESSION['name']=$lusername2;

        }
      header('location:profilenotifaction.php');
      } else {
      ?> <script type="text/javascript">
        alert('invalid username and password')
      </script>
      <?php
      }

    }
}

 ?>
 <!DOCTYPE html>
 <html lang="en" dir="ltr">
   <head>
     <meta charset="utf-8">
     <title></title>
   </head>
   <body>
     <form class="" action="#" method="post">
       <h2>Login From</h2>
       <div class="form-group">
         <label >Username</label>
         <input type="text" name="lu1" value="" class="form-control">
       </div>
       <div class="form-group">
         <label >Password</label>
         <input type="password" name="lp1" value="" class="form-control">
       </div>
       <button type="submit"name="loginsubmitbutton" class="btn btn-primary">Login</button>
     </form>
   </body>
 </html>

<?php
$con=mysqli_connect('localhost','root','','dashbord');
if (isset($_POST['su1']))
{
  $name1/*new variable*/=$_POST['n1']/* inputbox name="n1"*/;
  $email1=$_POST['e1'];
  $username1=$_POST['u1'];
  $password1=$_POST['p1'];
  $mobile1=$_POST['m1'];
  $gender1=$_POST['g1'];
  $hobbies1=$_POST['h1'];
  $photo1=$_POST['ph1'];
  $dob1=$_POST['d1'];
  $sql="insert into adminsignup values(null,'".$name1."','".$email1."','".$username1."','".$password1."','".$mobile1."','".$gender1."','".$hobbies1."','".$photo1."','".$dob1."')";
  $res=mysqli_query($con,$sql);
  if ($res)
  {
    header('location:signup.php? msg=created account');
  }
  else {
      header('location:signup.php? msg=try again create account');
  }
}


 ?>
 <!DOCTYPE html>
 <html lang="en" dir="ltr">
   <head>
     <meta charset="utf-8">
     <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
     <!--iconlink--> <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"><!--close iconlink-->
     <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" >
     <link rel="icon" type="image/ico" href="6.jpg"/>
     <title>user profile </title>
   </head>
   <body>
     <div class="container-fulid bg-info">


   <nav class="navbar navbar-expand-lg navbar-light bg-dark ">
   <a class="navbar-brand col-lg-2 text-light" href="#">Online Notice Board</a>
   <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
     <span class="navbar-toggler-icon"></span>
   </button>

   <div class="collapse navbar-collapse " id="navbarSupportedContent">
     <ul class="navbar-nav mr-auto col-lg-4">
       <li class="nav-item">
         <a class="nav-link fa fa-info-circle text-light" href="#"> About</a>
       </li>
       <li class="nav-item">
         <a class="nav-link fa fa-address-book-o text-light" href="#"> Contact</a>
       </li>

     </ul>
     <form class="form-inline ">
         <ul class="navbar-nav ">
       <li class="nav-item ">
         <a class="nav-link fa fa-user text-light" href="signup.php"> Signup</a>
       </li>
       <li class="nav-item">
         <a class="nav-link fa fa-sign-in text-light" href="index.php"> Login</a>
       </li>
     </ul>
     </form>
   </div>
 </nav>
     </div>
     </div>
     <div class="container">
       <div class="row">
         <div class="col">
     <form class="" action="" method="post">
       <br><br>
        <center><h1> Sign Up</h1></center>
         <?php
         if (isset($_GET['msg'])) {
           ?><font color="red"> <?php echo $_GET['msg'];?></font><?php
         }
          ?>
          <div class="form-group">
          <label>Name</label>
          <input type="text" name="n1" value="" class="form-control">
          </div>
          <div class="form-group">
          <label>Email-id</label>
          <input type="email" name="e1" value="" class="form-control">
          </div>
          <div class="form-group">
          <label>username</label>
          <input type="text" name="e1" value="" class="form-control">
          </div>
          <div class="form-group">
          <label>password</label>
          <input type="password" name="n1" value="" class="form-control">
          </div>
          <div class="form-group">
          <label>Mobile</label>
          <input type="number" name="m1" value="" class="form-control">
          </div>
          <div class="form-check form-check-inline">
          <label>Gender</label>
  <input class="form-check-input" type="radio" name="g1"  value="male">
  <label class="form-check-label" for="inlineRadio1">Male</label>
</div>
<div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="g1"  value="female">
  <label class="form-check-label" for="inlineRadio2">Female</label>
</div>
<div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="g1"  value="other" >
  <label class="form-check-label" for="inlineRadio3">Orther</label>
</div>
          <div class="form-group">
          <label>Hobbies</label>
          <input type="text" name="h1" value="" class="form-control">
          </div>
          <div class="form-group">
          <label>photo</label>
          <input type="file" name="ph1" value="" class="form-control">
          </div>
          <div class="form-group">
          <label>Date</label>
          <input type="date" name="d1" value="" class="form-control">
          </div>
                       <input type="submit" name="su1" value="submit" class="btn btn-primary"></th>
                       <a href="index.php">login</a></th><br></th>

     </form>
   </div>
 </div>
</div>
     <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
     <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" ></script>
     <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" ></script>
   </body>
 </html>

<?php
session_start();
session_destroy();
if (isset($_SESSION['name'])) {
  header('location:index.php? msg1=logoutpage');
}

 ?>

<?php  ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <div class="container-fulid bg-dark">
      <?php include 'profilehader.php' ?>
    </div>
    <div class="container-fulid">
      <div class="row">
      <div class="col-lg-4">
        <?php include 'profilenavbar.php' ?>
      </div>
      <div class="col-lg-8">
        <form class="" action="" method="post">
          <h2> Update Info</h2>
            <?php
            if (isset($_GET['msg'])) {
              echo $_GET['msg'];
            }
             ?>
             <div class="form-group">
               <label >Enter Notices Id</label>
               <input type="number" name="ni1" placeholder="" required class="form-control">
             </div>
             <div class="form-group">
               <label >Enter Subject</label>
               <input type="text" name="ns1" placeholder="" required class="form-control">
             </div>
             <div class="form-group">
               <label >Enter Descripation</label>
              <textarea name="nd1" rows="8" cols="80" class="form-control"></textarea>
             </div>
             <div class="form-group">
               <label >Date</label>
               <input type="date" name="ndate1" placeholder="" required class="form-control">
             </div>
             <a href="Upadate.php"> <button type="submit" name="update1" class="btn btn-primary">Update</button> </a>
             <a href="profilenotifaction.php"> go back</a>
        </form>


  </body>
</html>
<?php
$con=mysqli_connect('localhost','root','','dashbord');

if ($con) {
  if (isset($_POST['update1'])) {
      $nid1/*new variable*/=$_POST['ni1']/* inputbox name="n1"*/;
      $usubject1=$_POST['ns1'];
      $udesc1=$_POST['nd1'];
      $udate1=$_POST['ndate1'];
    $sql="update noticesbord set notices_id='$nid1',	sub='$usubject1',descripation='$udesc1',date='$udate1' where notices_id='$nid1'";
    $res=mysqli_query($con,$sql);
    if ($res)
    {
      ?> <script type="text/javascript">
        alert('Upadate password Successfully!!!')
      </script>
      <?php
      header('location:update.php? msg=update details');
    }

  }
  }
 ?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="css/bootstrap.css"/>
		<script src="js/jquery_library.js"></script>
<script src="js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  </head>
  <body>


    <?php
    session_start();
    $upd_name=$_SESSION['name'];
    echo $upd_name;
  include 'dhp.php';

  $sql="select * from user where name='".$upd_name."'";
    $result=mysqli_query($conn,$sql);
    $record=mysqli_fetch_assoc($result);
    $db_email=$record['email'];
    $db_password=$record['password'];
    $db_mobile=$record['mob'];
    $db_gender=$record['gen'];
  $db_hobbie=$record['hob'];
    $db_dob=$record['dob'];

     ?>



  <div class="container-fulid ">
      <nav class="navbar navbar-default navbar-fixed-top" style="background:#000">
        <div class="container">

        <ul class="nav navbar-nav navbar-left">
          <li><a href="index1.php" style="color:white"><strong>Hello<?php echo $_SESSION['name']?></strong></a></li>


        </ul>


      <ul class="nav navbar-nav navbar-right">
            <li><a href="logout.php" style="color:white">Logout</a></li>

          </ul>
        </div>
</nav>
</div><br><br><br>

<div class="container-fluid">

<div class="row">

  <div class="col-lg-3 lg-text-center">
      <h3 class="bg-info">User Profile</h3>
    <img src="images/person.jpg">

    <a href="changepassword.php" class="fa fa-key"> change password</a><br><br>
    <a href="update_profile.php"  class="fa fa-user"> update profile</a><br><br>
    <a href="notification.php" class="fa fa-bell"> notifaction</a><br><br>


  </div>
  <div class="col-lg-9" style="text-align:center">

    <h2>UpdateProfile</h2>
            <form class="" action="update_profile_handler.php" method="post"><br><br>
    Enter Your Name:     <input type="text" name="name" placeholder="name" value="<?php echo $upd_name?>"><br><br>
    Enter Your Email_Id: <input type="email" name="email" placeholder="email" value="<?php echo $db_email?>"readonly ><br><br>
    Enter Your Password: <input type="password" name="password" placeholder="password" value="<?php echo $db_password ?>"><br><br>
    Enter Your Mobile:  <input type="tel" name="mob" placeholder="mobile_No"value="<?php echo $db_mobile?>"><br><br>
    Enter Your Gender:  <input type="text" name="gen"placeholder="gender"value="<?php echo $db_gender?>"><br><br>
    Enter Your Hobbies : <input type="text" name="hob" placeholder="hobbie"value="<?php echo $db_hobbie?>"> <br><br>
    <!--Upload_Your_Image:<input type="file" name="img"><br><br>-->
    Enter Your DOB: <input type="date" name="dob"value="<?php echo $db_dob?>"readonly><br><br>
    <input class="btn btn-success" type="submit"name="update"value="Update">
    <input class="btn btn-success" type="submit"name="reset"value="Reset">

    </form>

  </div>

</div>

</div>




  </body>
</html>

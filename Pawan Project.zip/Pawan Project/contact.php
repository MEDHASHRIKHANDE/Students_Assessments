<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>

    <link rel="stylesheet" href="css/bootstrap.css"/>
		<script src="js/jquery_library.js"></script>
<script src="js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  </head>
  <body>

    <nav class="navbar navbar-default navbar-fixed-top" style="background:#000">
      <div class="container">

      <ul class="nav navbar-nav navbar-left">
        <li><a href="index.php"><strong>Online Notice Board</strong></a></li>


    	  <li><a href="about.php"><i class="fa fa-user" aria-hidden="true"></i> About</a></li>



    	<li><a href="contact.php"><i class="fa fa-mobile" aria-hidden="true"></i>Contact</a></li>

    	</ul>


    <ul class="nav navbar-nav navbar-right">
          <li><a href="registration.php"><i class="fa fa-user" aria-hidden="true"></i> Sign Up</a></li>
          <li><a href="login.php"><i class="fa fa-sign-in" aria-hidden="true"></i> Login</a></li>
        </ul>



    </div>
    </nav>

    <div class="container-fluid">

    <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">

      <ol class="carousel-indicators">
        <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
        <li data-target="#carousel-example-generic" data-slide-to="1"></li>
        <li data-target="#carousel-example-generic" data-slide-to="2"></li>
      </ol>


      <div class="carousel-inner" role="listbox">
        <div class="item active">
          <img src="images/Desert.jpg" alt="...">
          <div class="carousel-caption">
            ...
          </div>
        </div>
        <div class="item">
          <img src="images/Jellyfish.jpg" alt="...">
          <div class="carousel-caption">
            ...
          </div>
        </div>

    	 <div class="item">
          <img src="images/Penguins.jpg" alt="...">
          <div class="carousel-caption">
            ...
          </div>
        </div>
        ...
      </div>


      <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
        <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
      </a>
      <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
        <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
      </a>
    </div>

    </div>
    <div class="container">
    	<div class="row">

    		<div class="col-sm-8">
          <h2>Quick Contact</h2>
          <form method="post">
          	<div class="row">
          		<div class="col-md-8">
          		<div class="row">
          		<div class="col-sm-4"></div>
          		<div class="col-sm-4"><?php echo @$err;?></div>
          	</div>



          	<div class="row">
          		<div class="col-sm-4">Enter YOur Email</div>
          		<div class="col-sm-5">
          		<input type="email" name="e" class="form-control"/></div>
          	</div>

          	<div class="row">
          		<div class="col-sm-4">Enter YOur Mobile</div>
          		<div class="col-sm-5">
          		<input type="password" name="p" class="form-control"/></div>
          	</div>

          	<div class="row">
          		<div class="col-sm-4">Enter YOur Message</div>
          		<div class="col-sm-5">
          		<input type="password" name="p" class="form-control"/></div>
          	</div>

          	<div class="row" style="margin-top:10px">
          		<div class="col-sm-2"></div>
          		<div class="col-sm-8">
          		<input type="submit" value="Send Query" name="save" class="btn btn-success"/>

          		</div>
          	</div>

          		</div>
          		<div class="col-md-4">
          		<h2>Contact us</h2>

          		Name: Sanjeev Kumar<br/>
          		Mobile: 9015501897<br/>
          		Email:phptpoint@gmail.com<br/>
          		Website: <a href="http://www.phptpoint.com/">Phptpoint</a>
          		</div>
          	</div>


          </form>

    		</div>


    		<div class="col-sm-4">
    			<div class="panel panel-default">
      <div class="panel-heading">Latest news</div>
      <div class="panel-body">
        this is the best website
    	you can search anything here
    	the best thumfjdfug
      </div>
    </div>

    		</div>
    	</div>

    </div>



    <br>
    <br>
    <br>
    <br>



    			<nav class="navbar navbar-default navbar-bottom" style="background:black">
      <div class="container">

      <ul class="nav navbar-nav navbar-left">
        <li><a href="#" > Developed by Jadhav</a></li>

    	</ul>




    </div>
    </nav>









  </body>
</html>

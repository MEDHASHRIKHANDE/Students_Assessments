-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jul 11, 2019 at 12:52 PM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `demo`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(10) NOT NULL,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `username`, `password`) VALUES
(1, 'admin@gmail.com', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `notification`
--

CREATE TABLE `notification` (
  `sr` int(20) NOT NULL,
  `user_name` varchar(200) DEFAULT NULL,
  `subject` varchar(200) DEFAULT NULL,
  `details` text DEFAULT NULL,
  `date` datetime(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notification`
--

INSERT INTO `notification` (`sr`, `user_name`, `subject`, `details`, `date`) VALUES
(1, 'shailesh salvi', 'I am  late today', 'dear sir ,\r\nI am shailesh salvi...\r\nI coming late for train on struck......', '2019-07-11 14:11:44.000000'),
(2, 'mahesh', 'hi...', 'sacasfsefewfsd', '2019-07-11 15:32:30.000000');

-- --------------------------------------------------------

--
-- Table structure for table `user_data`
--

CREATE TABLE `user_data` (
  `id` int(11) NOT NULL,
  `name` varchar(200) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `mobile` bigint(20) DEFAULT NULL,
  `gender` varchar(200) DEFAULT NULL,
  `hobbies` varchar(100) DEFAULT NULL,
  `img` varchar(200) DEFAULT NULL,
  `dob` datetime(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_data`
--

INSERT INTO `user_data` (`id`, `name`, `email`, `password`, `mobile`, `gender`, `hobbies`, `img`, `dob`) VALUES
(1, 'shailesh salvi', 'spsalvi93@gmail.com', '123456789', 94212329, 'female', NULL, '', '2019-05-01 00:00:00.000000'),
(2, 'mahesh', 'mahesh@gmail.com', '1234', 94212329, 'female', NULL, '', '2019-06-20 00:00:00.000000'),
(3, 'saj', 'q@gmail.com', '12345678', 21212, 'female', NULL, '', '2019-01-07 00:00:00.000000'),
(4, 'aaaaaa', 'aaaaa@gmail.com', '121212', 2222, 'male', NULL, '', '2019-01-01 00:00:00.000000'),
(5, 'sam', 'sam@gmail.com', '12345', 2222, 'male', NULL, '', '2019-01-07 00:00:00.000000'),
(6, 'ans', 'ans@gmail.com', '1212', 1111, 'female', NULL, '', '2019-01-14 00:00:00.000000'),
(7, '22', '22@gmail.com', '22', 22222, 'female', '', '', '2019-01-07 00:00:00.000000'),
(8, '21q', '21q@gmail.com', '32332', 212222, 'female', '', '', '2019-01-22 00:00:00.000000'),
(9, 'sandip', 'sandip@gmail.com', 'sam', 2323, 'female', '', '', '2019-02-26 00:00:00.000000'),
(10, 'sandip', 'sandip@gmail.com', '1234', 3333, 'female', '', '', '2019-03-26 00:00:00.000000'),
(11, 'metab', 'MD@gmail.com', '1212212', 2222222, 'female', '', '', '2019-07-16 00:00:00.000000'),
(12, 'metab', 'MD@gmail.com', '1212212', 2222222, 'female', '', '', '2019-07-16 00:00:00.000000'),
(13, 'metab', 'Md@gmail.com', '1234', 1212, 'female', '', '', '2019-02-06 00:00:00.000000'),
(14, 'aasa', 'saaa@gmail.com', '12345', 223, 'female', '', '', '2019-02-12 00:00:00.000000');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `notification`
--
ALTER TABLE `notification`
  ADD PRIMARY KEY (`sr`);

--
-- Indexes for table `user_data`
--
ALTER TABLE `user_data`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `notification`
--
ALTER TABLE `notification`
  MODIFY `sr` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `user_data`
--
ALTER TABLE `user_data`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

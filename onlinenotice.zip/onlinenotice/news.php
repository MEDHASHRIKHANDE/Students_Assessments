 <!DOCTYPE html>
 <html lang="en" dir="ltr">
   <head>
     <meta charset="utf-8">
     <title></title>

   </head>
   <body>
     
     <form class="" action="#" method="post">
       <h3 class="text-success">Latest News</h3>
       <?php
       $con=mysqli_connect('localhost','root','','test2');
       $sql="select * from News order by date desc";
       $res=mysqli_query($con,$sql);
       echo " <table class='py-3' border='1'><tr class='bg-success'><th>Title</th><th>Desc</th><th>Date</th></tr>";
       if ($res-> num_rows >0)
       {
         while($row=$res->fetch_assoc()){

         echo "<tr>";
         echo "<td>".$row['title']."</td>";
         echo "<td>".$row['description']."</td>";
         echo "<td>".$row['date']."</td>";
         echo "</tr>";
       }
       }
       echo "</table>";

        ?>

     </form>
   </body>
 </html>

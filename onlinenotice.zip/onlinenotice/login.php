<?php
$con=mysqli_connect('localhost','root','','test2');
if (isset($_POST['login'])) {
  $lusername1=$_POST['lu1'];
  $lpassword1= $_POST['lp1'];

    $res=mysqli_query($con,"select * from signup where username ='$lusername1'");
    if ($res) {
      $record=mysqli_fetch_assoc($res);
      $lusername2=$record['username'];
      $lpassword2=$record['password'];
      if ($lusername2===$lusername1 && $lpassword2===$lpassword1) {
        if ($lusername1){
          session_start();
            $_SESSION['username']=$lusername2;

        }
      header('Location:notifaction.php');
      } else {
        header('Location:login.php?msg=invalid username and password');
      }

    }
}

 ?>
 <!DOCTYPE html>
 <html lang="en" dir="ltr">
   <head>
     <meta charset="utf-8">
     <title></title>
   </head>
   <body>
     <form class="" action="#" method="post">
       <h2>Login From</h2>
       <table>
         <tr>
           <tr>
             <th>usename</th>
             <td> <input type="text" name="lu1" value=""> </td>
           </tr>

           <tr>
             <th>password</th>
             <td> <input type="password" name="lp1" value=""> </td>
           </tr>
         </tr>
         <tr>
           <th><input type="submit" name="login" value="Login">  </th>
         </tr>
       </table>
     </form>
   </body>
 </html>

-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jul 12, 2019 at 09:05 AM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test2`
--

-- --------------------------------------------------------

--
-- Table structure for table `adminsignup`
--

CREATE TABLE `adminsignup` (
  `sid` int(50) NOT NULL,
  `name` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `email` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `username` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `password` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `mobile` bigint(20) DEFAULT NULL,
  `gender` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `hobbies` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `image` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `dob` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `adminsignup`
--

INSERT INTO `adminsignup` (`sid`, `name`, `email`, `username`, `password`, `mobile`, `gender`, `hobbies`, `image`, `dob`) VALUES
(1, 'mahesh', 'mahesh.hande1@gmail.com', 'mahesh123', '12345678', 987654367, 'male', 'crickt', 'light-bulb.gif', '2019-01-29'),
(2, 'mehtab', 'mehtab@gmail.com', 'mehtab123', '09876543', 876545678, 'male', 'watching tv', 'pic_bulboff.gif', '2019-07-09');

-- --------------------------------------------------------

--
-- Table structure for table `News`
--

CREATE TABLE `News` (
  `news_id` int(50) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `News`
--

INSERT INTO `News` (`news_id`, `title`, `description`, `date`) VALUES
(1, 'marathi', 'marahti is maharashtra\'s first or official language', '2019-07-08'),
(2, 'marathi', 'marahti is maharashtra\'s first or official language', '2019-07-08');

-- --------------------------------------------------------

--
-- Table structure for table `noticeboard`
--

CREATE TABLE `noticeboard` (
  `notices_id` int(50) NOT NULL,
  `username` varchar(255) DEFAULT NULL,
  `sub` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `noticeboard`
--

INSERT INTO `noticeboard` (`notices_id`, `username`, `sub`, `description`, `date`) VALUES
(1, 'mahesh567', 'marathi', 'marathi is langauage for marathi manus', '2019-07-08'),
(2, 'mahesh567', 'marathi', 'marathi is langauage for marathi manus', '2019-07-08');

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--

CREATE TABLE `signup` (
  `id` int(50) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `emailid` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `mobile` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `hobbies` varchar(255) DEFAULT NULL,
  `photo` longtext DEFAULT NULL,
  `dob` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `signup`
--

INSERT INTO `signup` (`id`, `name`, `emailid`, `username`, `password`, `mobile`, `gender`, `hobbies`, `photo`, `dob`) VALUES
(1, 'amit shaw', 'amit123@gmail.com', 'mahesh123', '123456', '865434567', 'male', 'reading wathinfg', 'women-leader-featured-image.jpg', '2019-01-08'),
(2, 'SAJAN PADAD', 'sajan123@gmail.com', 'mehtab123', '1234567', '', 'male', 'reading waching', 'SBI-PO-Female.jpg', '1996-07-08'),
(3, 'SAJAN PADAD', 'sajan123@gmail.com', 'shailesh123', '123478', '', 'male', 'reading waching', 'SBI-PO-Female.jpg', '1996-07-08'),
(4, 'SAJAN PADAD', 'sajan123@gmail.com', 'priya123', 'manjarekar', '', 'female', 'reading waching', 'SBI-PO-Female.jpg', '1996-07-08'),
(5, 'sajan123', 'sajan.padad123@gmail.com', 'sajan123', '123456', '', 'male', 'reading', '3.jpeg', '2019-07-01'),
(6, 'SAJAN PADAD', 'sajan123@gmail.com', 'mahesh567', '123456', '', 'male', 'reading waching', 'SBI-PO-Female.jpg', '1996-07-08'),
(8, 'SAJAN PADAD', 'sajan123@gmail.com', 'sajanpadad', '123456789', '', 'male', 'reading waching', 'SBI-PO-Female.jpg', '1996-07-08'),
(9, 'priyanka', 'priyankakdubey@gmail.com', 'priyanka123', '12345678', '98765433456', '', 'reading chatting', 'women-leader-featured-image.jpg', '2019-07-03'),
(10, 'amit shaw', 'amitshaw@gmail.com', 'amit123', '123456789', '98765434567', '', 'reading', 'code.png', '2019-01-04');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `adminsignup`
--
ALTER TABLE `adminsignup`
  ADD PRIMARY KEY (`sid`);

--
-- Indexes for table `News`
--
ALTER TABLE `News`
  ADD PRIMARY KEY (`news_id`);

--
-- Indexes for table `noticeboard`
--
ALTER TABLE `noticeboard`
  ADD PRIMARY KEY (`notices_id`);

--
-- Indexes for table `signup`
--
ALTER TABLE `signup`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `adminsignup`
--
ALTER TABLE `adminsignup`
  MODIFY `sid` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `News`
--
ALTER TABLE `News`
  MODIFY `news_id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `noticeboard`
--
ALTER TABLE `noticeboard`
  MODIFY `notices_id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `signup`
--
ALTER TABLE `signup`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

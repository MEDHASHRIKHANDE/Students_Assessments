<?php  ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!--iconlink--> <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"><!--close iconlink-->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" >
    <link rel="icon" type="image/ico" href="6.jpg"/>
    <title>user profile </title>
  </head>
  <body>
    <div class="container-fulid">
      <?php include 'profilehead.php' ?>
    </div>
    <div class="container-fulid">
      <div class="row">
      <div class="col-lg-4">
        <?php include 'profilenav.php'; include 'conncetion.php'; ?>
      </div>
        <div class="col-lg-8">
          <?php
          $s1=$_SESSION['username'];
          //$con=mysqli_connect('localhost','root','','test2');
          $sql="select * from signup where username='$s1'";
          $res=mysqli_query($con,$sql);
          echo "<br><br><h2>All Profile Info</h2>";
          echo "<table border='1'><tr><th>name</th><th>email</th><th>username</th><th>mobile</th><th>gender</th><th>hobbies</th><th>photo</th><th>dob</th><th>update</th><th>delete</th></tr>";
          if ($res-> num_rows >0)
          {
            while($row=$res->fetch_assoc()){
              echo "<tr>";
              echo "<td>".$row['name']."</td>";
              echo "<td>".$row['email']."</td>";
              echo "<td>".$row['username']."</td>";
              echo "<td>".$row['mobile']."</td>";
              echo "<td>".$row['gender']."</td>";
              echo "<td>".$row['hobbies']."</td>";
              echo "<td>".$row['photo']."</td>";
              echo "<td>".$row['dob']."</td>";
              echo "<td><a href='update_profile.php'><i class='fa fa-pencil-square-o'></i></a></td>";
              echo "<td><a href='profiledelete.php'><i class='fa fa-trash-o'></i></a></td>";
              echo "</tr>";
          }
          }
           echo "</table>";
          ?>
        </div>
      </div>
</div>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" ></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" ></script>
  </body>
</html>

<?php
$con=mysqli_connect('localhost','root','','test2');
if (isset($_POST['addnot']))
{
  $nusername1=$_POST['nu1'];
  $usubject1=$_POST['ns1'];
  $udesc1=$_POST['nd1'];
  $udate1=$_POST['ndate1'];
  $sql="insert into noticesbord values(null,'".$nusername1."','".$usubject1."','".$udesc1."','".$udate1."')";
  $res=mysqli_query($con,$sql);
  if ($res)
  {
    header('Location:addnotices.php? msg=add notices success!!');
  }
  else {
      header('Location:addnotices.php? msg=try again insert notices');
  }
}


 ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!--iconlink--> <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"><!--close iconlink-->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" >
    <link rel="icon" type="image/ico" href="6.jpg"/>
    <title>user profile </title>
  </head>
  <body>
    <div class="container-fulid bg-dark">
      <?php include 'profilehader.php' ?>
    </div>
    <div class="container-fulid">
      <div class="row">
      <div class="col-lg-4">
        <?php include 'profilenavbar.php' ?>
      </div>
    <form class="" action="#" method="post">
      <center>
      <h2>Add Notification</h2>
      <?php
      if (isset($_GET['msg'])) {
        echo $_GET['msg'];
      }
       ?>
      <table>
        <tr>
          <tr>
            <th>Enter Username</th>
            <td> <input type="text" name="nu1" value=""> </td>
          </tr>
        </tr>
          <tr>
            <th>Enter Subject</th>
            <td> <input type="text" name="ns1" value=""> </td>
          </tr>

          <tr>
            <th>Enter Descripation</th>
            <td> <input type="text" name="nd1" value=""> </td>
          </tr>
          <tr>
            <th>Date</th>
            <td> <input type="date" name="ndate1" value=""> </td>
          </tr>
        </tr>

        <tr>
          <th><input type="submit" name="addnot" value="Add Notification">  </th>
            <th> <button><a href="notifaction.php">Go Back</a></button></th>
        </tr>
      </table>
    </center>
    </form>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" ></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" ></script>
  </body>
</html>

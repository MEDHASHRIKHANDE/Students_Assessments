<?php
$con=mysqli_connect('localhost','root','','test2');
if (isset($_POST['login'])) {
  $lusername1=$_POST['lu1'];
  $lpassword1= $_POST['lp1'];

    $res=mysqli_query($con,"select * from adminsignup where username ='$lusername1'");
    if ($res) {
      $record=mysqli_fetch_assoc($res);
      $lusername2=$record['username'];
      $lpassword2=$record['password'];
      if ($lusername2===$lusername1 && $lpassword2===$lpassword1) {
        if ($lusername1){
          session_start();
            $_SESSION['username']=$lusername2;

        }
      header('Location:profilenotifaction.php');
      } else {
      ?> <script type="text/javascript">
        alert('invalid username and password')
      </script>
      <?php
      }

    }
}

 ?>
 <!DOCTYPE html>
 <html lang="en" dir="ltr">
   <head>
     <meta charset="utf-8">
     <title></title>
   </head>
   <body>
     <form class="" action="#" method="post">
       <center><h1 class="text-danger">Admin Panel</h1>
       <h4>Login Form</h4><br>
       <table>
         <tr>
           <tr>
             <th>Username:</th>
             <td> &nbsp;&nbsp;&nbsp;<input type="text" name="lu1" value=""> </td>
           </tr>

           <tr>
             <th>Password:</th>
             <td>&nbsp;&nbsp; <input type="password" name="lp1" value=""> </td>
           </tr>
         </tr>
         <tr>
           <th style="margin-left:20em;"><input class="btn btn-success" type="submit" name="login" value="Login">  </th>
         </tr>
       </table>
     </center>
     </form>
   </body>
 </html>

<?php  ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <div class="container-fulid bg-dark">
      <?php include 'profilehader.php' ?>
    </div>
    <div class="container-fulid">
      <div class="row">
      <div class="col-lg-4">
        <?php include 'profilenavbar.php' ?>
      </div>
      <div class="col-lg-8">
        <br><br>
    <h2 class="text-center text-primary">Update Password</h2><br><br>
    <?php
    if (isset($_GET['msg'])) {
      echo "<font color='#28B463'>".$_GET['msg']."</font>";
    }
    "</font>" ?>
    <form class="" action="" method="post">
      <div class="form-group">
    <label >Username</label>
    <input type="text" name="upadateuser" placeholder="username" required class="form-control">
  </div>
  <div class="form-group">
    <label> New Password</label>
    <input type="text" name="upadatepass" value="" placeholder="new password" required class="form-control">
  </div>
      <button type="submit" name="update1" value="" class="btn btn-primary">update</button>
    </form>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" ></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" ></script>
  </body>
</div>
</div>
</div>
  </body>
</html>
<?php
$con=mysqli_connect('localhost','root','','test2');
if ($con) {
  if (isset($_POST['update1'])) {
    $up1=$_POST['upadateuser'];
    $up2=$_POST['upadatepass'];
    $sql="update adminsignup set password='$up2' where username='$up1'";
    $res=mysqli_query($con,$sql);
    if ($res)
    {
      header('Location:changepassword.php? msg=Upadate password Successfully!!!');
    }
    else {
          header('Location:changepassword.php? msg=Try Again');
    }
  }
}


else {
  echo "not update";
}
 ?>

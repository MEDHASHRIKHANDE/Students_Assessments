<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"><!--close iconlink-->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" >
    <link rel="icon" type="image/ico" href="6.jpg"/>
    <title>website</title>


  </head>
  <body>
    <div class="container-fulid bg-info">
  <nav class="navbar navbar-expand-lg navbar-light bg-dark ">
  <a class="navbar-brand col-lg-2 text-light" href="#">Online Notice Board</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse " id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto col-lg-4">
      <li class="nav-item">
        <a class="nav-link fa fa-info-circle text-light" href="#"> About</a>
      </li>
      <li class="nav-item">
        <a class="nav-link fa fa-address-book-o text-light" href="#"> Contact</a>
      </li>

    </ul>
    <form class="form-inline ">
        <ul class="navbar-nav ">
      <li class="nav-item ">
        <a class="nav-link fa fa-user text-light" href="signupadmin.php"> Signup</a>
      </li>
      <li class="nav-item">
        <a class="nav-link fa fa-sign-in text-light" href="index.php"> Login</a>
      </li>
    </ul>
    </form>
  </div>
</nav>
    </div>
    <br><br><br>
    <div class="container">
      <?php
      if (isset($_GET['msg'])) {
        echo $_GET['msg'];
      }
       ?>
      <div class="col " id="login"> <?php include 'login.php';?> </div>
    </div>
    <br><br>

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" ></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" ></script>
  </body>
</html>

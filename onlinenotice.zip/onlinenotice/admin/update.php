<?php  ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <div class="container-fulid bg-dark">
      <?php include 'profilehader.php' ?>
    </div>
    <div class="container-fulid">
      <div class="row">
      <div class="col-lg-4">
        <?php include 'profilenavbar.php' ?>
      </div>
      <div class="col-lg-8">
        <form class="" action="" method="post">
          <h2> Update Info</h2>
            <?php
            if (isset($_GET['msg'])) {
              echo $_GET['msg'];
            }
             ?>
          <table>
<tr>
            <tr>
              <th>Enter Notices Id</th>
              <td> <input type="number" name="ni1" value=""> </td>
            </tr>
            <tr>
              <th>Enter Subject</th>
              <td> <input type="text" name="ns1" value=""> </td>
            </tr>

            <tr>
              <th>Enter Descripation</th>
              <td> <input type="text" name="nd1" value=""> </td>
            </tr>
            <tr>
              <th>Date</th>
              <td> <input type="date" name="ndate1" value=""> </td>
            </tr>
            <tr>
              <th><input type="submit" name="update1" value="update"></th>
              <th> <a href="profilenotifaction.php"> go back</a></th>
            </tr>
          </tr>
          </table>
        </form>


  </body>
</html>
<?php
$con=mysqli_connect('localhost','root','','test');

if ($con) {
  if (isset($_POST['update1'])) {
      $nid1/=$_POST['ni1'];
      $usubject1=$_POST['ns1'];
      $udesc1=$_POST['nd1'];
      $udate1=$_POST['ndate1'];
    $sql="update noticesbord set notices_id='$nid1',	sub='$usubject1',descripation='$udesc1',date='$udate1' where notices_id='$nid1'";
    $res=mysqli_query($con,$sql);
    if ($res)
    {
      ?> <script type="text/javascript">
        alert('Upadate password Successfully!!!')
      </script>
      <?php
      header('Location:update.php? msg=update details');
    }

  }
  }
 ?>

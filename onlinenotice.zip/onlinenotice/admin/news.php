 <!DOCTYPE html>
 <html lang="en" dir="ltr">
   <head>
     <meta charset="utf-8">
     <title></title>
   </head>
   <body>
     <form class="" action="#" method="post">
       <h3>Latest News</h3>
       <?php
       $con=mysqli_connect('localhost','root','','test2');
       $sql="select * from news order by date desc";
       $res=mysqli_query($con,$sql);
       echo " <table border='1'><tr><th>title</th><th>desc</th><th>date</th></tr>";
       if ($res-> num_rows >0)
       {
         while($row=$res->fetch_assoc()){

         echo "<tr>";
         echo "<td>".$row['title']."</td>";
         echo "<td>".$row['desc']."</td>";
         echo "<td>".$row['date']."</td>";
         echo "</tr>";
       }
       }
       echo "</table>";

        ?>

     </form>
   </body>
 </html>

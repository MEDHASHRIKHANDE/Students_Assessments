<?php
if (isset($_POST['delesubmit'])) {
  session_start();
  $con=mysqli_connect('localhost','root','','test2');
    $del2=$_SESSION['del1'];
  $res=mysqli_query($con,$query);
  $sql="delete from noticesbord where notices_id='".$del2."'";
  if ($res)
  {
    header('location:profiledelete.php? msg=Delete notices success!!');
  }
  else {
    ?>
    <script type="text/javascript">
      alert('try again delete notices')
    </script>
    <?php
  }
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"><!--close iconlink-->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" >
    <link rel="icon" type="image/ico" href="6.jpg"/>
    <title>user profile </title>
  </head>
  <body>
      <div class="col-lg-8">
        <?php
        if (isset($_GET['msg'])) {
          echo $_GET['msg'];
        }
         ?>
    <form class="" action="#" method="post">
      <table>
        <tr>
          <div class="form-group">
    <label >Notice Id</label>
    <input type="number" name="del1" value="" class="form-control" placeholder="<?php echo $_SESSION['del1']; ?>" disabled">
  </div>
  <button type="submit" name="delesubmit" class="btn btn-primary">Delete</button>&nbsp;&nbsp;
  <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        </tr>
      </table>
    </form>
  </div>
</div>
</div>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" ></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" ></script>
  </body>
  </body>
</html>

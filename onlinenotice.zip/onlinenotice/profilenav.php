<?php

 ?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"><!--close iconlink-->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" >
    <link rel="icon" type="image/ico" href="6.jpg"/>
    <title>user profile </title>
  </head>
  <body>
    <div class="container-fulid ">
      <div class="row">
        <div class="col">
          <h3 class="bg-info text-center">User Profile</h3><br><br>
          <img src="user.png" style="width:10em;margin-left:8em;"><br><br>
          <a style="margin-left:4em;font-size:1.5em;text-decoration:none;" href="changepassword.php" class="fa fa-key text-success"> Update Password</a><br><br>
          <a style="margin-left:4em;font-size:1.5em;text-decoration:none;"href="update_profile.php"  class="fa fa-user text-success"> Update Profile</a><br><br>
          <a style="margin-left:4em;font-size:1.5em;text-decoration:none;"href="notifaction.php" class="fa fa-bell text-success"> Notifaction</a><br><br>
          <a style="margin-left:4em;font-size:1.5em;text-decoration:none;"href="logout.php" class="fa fa-sign-out text-success"> Logout</a><br>
        </div>
        </div>
        </div>
        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" ></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" ></script>
        </body>
        </html>

 <!DOCTYPE html>
 <html lang="en" dir="ltr">
   <head>
     <meta charset="utf-8">
     <title></title>
   </head>
   <body>
     <form class="" action="#" method="post">
       <h3>Notice Board</h3>
       <?php
       $con=mysqli_connect('localhost','root','','test2');
       $sql="select * from noticesbord order by date desc";
       $res=mysqli_query($con,$sql);
       if ($res-> num_rows >0)
       {
         while($row=$res->fetch_assoc()){

         echo "<table><tr>
         <td>".$row['user_id']."</td>
         <td>".$row['sub']."</td>
         <td>".$row['desc']."</td>
         </tr></table>";

       }
       }
       else {
       echo "not table";
       }
        ?>
     </form>
   </body>
 </html>

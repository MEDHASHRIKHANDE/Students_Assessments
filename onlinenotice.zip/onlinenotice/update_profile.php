<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <div class="container-fulid bg-dark">
      <?php include 'profilehead.php' ?>
    </div>
    <div class="container-fulid">
      <div class="row">
      <div class="col-lg-4">
        <?php include 'profilenav.php' ?>
      </div>
      <div class="col-lg-8 ">
          <h2> Update Info</h2><hr>
            <?php
            if (isset($_GET['msg'])) {
              echo $_GET['msg'];
            }
             ?>
    <form class="" action="" method="post">
      <div class="row">
      <div class="col-2">
      <label>Name:</label><br><br>
      <label>email-id:</label><br><br>
      <label>mobile:</label><br><br>
    <label>hobbies:</label><br><br>
    <label>photo:</label><br><br>
    <label>dob:</label></div>
    <div class="col-4">
    <input type="text" name="n1" value="" required style="width:100%;"><br><br>
    <input type="email" name="e1" value="" required style="width:100%;"><br><br>
    <input type="tel" name="m1" value="" required style="width:100%;"><br><br>
    <input type="text" name="h1" value="" required style="width:100%;"><br><br>
    <input type="file" name="ph1" value="" required style="width:100%;"><br><br>
    <input type="date" name="d1" value="" required style="width:100%;"><br><br>
    <input type="submit" class="btn btn-success" name="update1" value="Update" style="width:10em; font-size:1.5em;"></div>
</div>  </form>
</div>
  </body>
</html>
<?php
$con=mysqli_connect("localhost","root","","test2");

if ($con) {
  if (isset($_POST['update1'])) {
    $s1=$_SESSION['username'];
    $updn1=$_POST['n1'];
    $upde1=$_POST['e1'];
    $updm1=$_POST['m1'];
    $updh1=$_POST['h1'];
    $updph1=$_POST['ph1'];
    $updd1=$_POST['d1'];
    $sql="update signup set name = '$updn1', emailid= '$upde1', mobile= '$updm1', hobbies= '$updh1', photo= '$updph1', dob= '$updd1' where username ='".$s1."'";
    $res=mysqli_query($con,$sql);
    if ($res)
    {
      header('Location:update_profile.php?msg=Update Successfully');
    }else{
      echo "error";
    }

  }
}else{
  echo "please enter correct information";
}
 ?>

<?php
if (isset($_POST['delete'])) {
  $con=mysqli_connect('localhost','root','','test2');
    $del2=$_POST['del1'];
  $sql="delete from signup where username='".$del2."'";
  $res=mysqli_query($con,$sql);
  if ($res) {
    header('location:profiledelete.php? msg=Delete Row');
  }
  else {
    header('location:profiledelete.php? msg=Check Username');
  }
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"><!--close iconlink-->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" >
    <link rel="icon" type="image/ico" href="6.jpg"/>
    <title>user profile </title>
  </head>
  <body>
    <div class="container-fulid">
      <?php include 'profilehead.php' ?>
    </div>
    <div class="container-fulid">
      <div class="row">
      <div class="col-lg-4">
        <?php include 'profilenav.php' ?>
      </div>
      <div class="col-lg-8">
        <br><br>
        <h2>All Delete Info</h2>
        <?php
        if (isset($_GET['msg'])) {
          echo $_GET['msg'];
        }
         ?>
    <form class="" action="#" method="post">
      <table>
        <tr>
          <tr>
            <th>usename</th>
            <td> <input type="text" name="del1" value=""> </td>
          </tr>
        <tr>
          <th><input type="submit" name="delete" value="Delete">  </th>
          <th> <a href="proupdate.php"></a> go back</th>
        </tr>
      </table>
    </form>
  </div>
</div>
</div>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" ></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" ></script>
  </body>
  </body>
</html>
